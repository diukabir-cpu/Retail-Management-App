import React, { Suspense, lazy } from 'react';
import type { AuthChallengeRequest } from '../hooks/useAdminAuth';
import { DashboardView } from '../modules/dashboard/DashboardView';
import type { ModuleId } from '../types/app';

const PosView = lazy(() => import('../modules/pos/PosView'));
const ProductsView = lazy(() => import('../modules/products/ProductsView'));
const CategoriesView = lazy(() => import('../modules/categories/CategoriesView'));
const SubcategoriesView = lazy(() => import('../modules/subcategories/SubcategoriesView'));
const VendorsView = lazy(() => import('../modules/vendors/VendorsView'));
const PurchasesView = lazy(() => import('../modules/purchases/PurchasesView'));
const CustomersView = lazy(() => import('../modules/customers/CustomersView'));
const MembershipView = lazy(() => import('../modules/membership/MembershipView'));
const ReturnsView = lazy(() => import('../modules/returns/ReturnsView'));
const PaymentsView = lazy(() => import('../modules/payments/PaymentsView'));
const ExpiryView = lazy(() => import('../modules/expiry/ExpiryView'));
const ReportsView = lazy(() => import('../modules/reports/ReportsView'));
const MasterDataView = lazy(() => import('../modules/masterData/MasterDataView'));
const ActivityLogsView = lazy(() =>
  import('../modules/activityLogs/ActivityLogsView').then((m) => ({ default: m.ActivityLogsView }))
);
const SettingsView = lazy(() =>
  import('../modules/settings/SettingsView').then((m) => ({ default: m.SettingsView }))
);

interface AppRouterProps {
  activeModule: ModuleId;
  onNavigate: (moduleId: ModuleId) => void;
  requestAuthorization: (params: Omit<AuthChallengeRequest, 'needsInitialSetup'>) => Promise<void>;
  onSettingsUpdated: () => void;
}

const ModuleLoadingFallback: React.FC = () => (
  <div className="space-y-4" aria-busy="true" aria-label="Loading module">
    <div className="h-28 animate-pulse rounded-2xl border border-slate-200 bg-white" />
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <div className="h-48 animate-pulse rounded-2xl border border-slate-200 bg-white" />
      <div className="h-48 animate-pulse rounded-2xl border border-slate-200 bg-white" />
    </div>
  </div>
);

export const AppRouter: React.FC<AppRouterProps> = ({
  activeModule,
  onNavigate,
  requestAuthorization,
  onSettingsUpdated,
}) => {
  if (activeModule === 'dashboard') {
    return <DashboardView onNavigate={onNavigate} />;
  }

  return (
    <Suspense fallback={<ModuleLoadingFallback />}>
      {activeModule === 'pos' && <PosView onNavigate={onNavigate} />}
      {activeModule === 'products' && <ProductsView onNavigate={onNavigate} />}
      {activeModule === 'categories' && <CategoriesView onNavigate={onNavigate} />}
      {activeModule === 'subcategories' && <SubcategoriesView onNavigate={onNavigate} />}
      {activeModule === 'vendors' && <VendorsView onNavigate={onNavigate} />}
      {activeModule === 'purchases' && <PurchasesView onNavigate={onNavigate} />}
      {activeModule === 'customers' && <CustomersView onNavigate={onNavigate} />}
      {activeModule === 'membership' && <MembershipView onNavigate={onNavigate} />}
      {activeModule === 'returns' && <ReturnsView onNavigate={onNavigate} />}
      {activeModule === 'payments' && <PaymentsView onNavigate={onNavigate} />}
      {activeModule === 'expiry' && <ExpiryView onNavigate={onNavigate} />}
      {activeModule === 'reports' && <ReportsView onNavigate={onNavigate} />}
      {activeModule === 'master-data' && <MasterDataView onNavigate={onNavigate} />}
      {activeModule === 'activity-logs' && <ActivityLogsView />}
      {activeModule === 'settings' && (
        <SettingsView
          requestAuthorization={requestAuthorization}
          onSettingsUpdated={onSettingsUpdated}
        />
      )}
    </Suspense>
  );
};
