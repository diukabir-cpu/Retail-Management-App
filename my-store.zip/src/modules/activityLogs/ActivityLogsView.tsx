import React, { useCallback, useEffect, useState } from 'react';
import { RefreshCw, Search } from 'lucide-react';
import { StatusAlert } from '../../components/StatusAlert';
import { useDebounce } from '../../hooks/useDebounce';
import { queryActivityLogs } from '../../services/activityLogService';
import type { ActivityLog } from '../../types/database';
import { normalizeError } from '../../utils/errorHandler';

export const ActivityLogsView: React.FC = () => {
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [searchInput, setSearchInput] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | ActivityLog['status']>('all');
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const debouncedSearch = useDebounce(searchInput, 200);

  const loadLogs = useCallback(async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const results = await queryActivityLogs({
        search: debouncedSearch,
        status: statusFilter,
        limit: 150,
      });
      setLogs(results);
    } catch (err) {
      setErrorMsg(normalizeError(err).userMessage);
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, statusFilter]);

  useEffect(() => {
    void loadLogs();
  }, [loadLogs]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">Activity Logs</h2>
          <p className="mt-0.5 text-sm text-slate-500">
            Local audit trail for database initialization, password actions, settings changes, and backups.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            void loadLogs();
          }}
          disabled={loading}
          className="inline-flex min-h-[42px] items-center gap-2 self-start rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} aria-hidden="true" />
          Refresh
        </button>
      </div>

      {errorMsg && <StatusAlert tone="error" message={errorMsg} />}

      {/* Search and Filter Toolbar */}
      <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1">
          <label htmlFor="activity-log-search" className="sr-only">
            Search activity logs
          </label>
          <Search
            className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400"
            aria-hidden="true"
          />
          <input
            id="activity-log-search"
            type="search"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search by action, module, or summary..."
            className="w-full min-h-[42px] rounded-lg border border-slate-200 bg-slate-50 py-2 pr-3 pl-9 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:bg-white focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1 shrink-0" role="group" aria-label="Filter logs by status">
          {(['all', 'success', 'denied', 'error'] as const).map((status) => (
            <button
              key={status}
              type="button"
              onClick={() => setStatusFilter(status)}
              className={`min-h-[34px] rounded-md px-3 py-1.5 text-xs font-medium capitalize transition-colors ${
                statusFilter === status
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Log Table / Responsive List */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
        {loading ? (
          <div className="space-y-3 p-6">
            <div className="h-10 animate-pulse rounded-lg bg-slate-100" />
            <div className="h-10 animate-pulse rounded-lg bg-slate-100" />
            <div className="h-10 animate-pulse rounded-lg bg-slate-100" />
          </div>
        ) : logs.length === 0 ? (
          <div className="p-10 text-center">
            <p className="text-sm font-medium text-slate-900">No matching activity logs</p>
            <p className="mt-1 text-xs text-slate-500">
              Adjust your search filter or perform a protected operation in Settings.
            </p>
          </div>
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden overflow-x-auto md:block">
              <table className="w-full border-collapse text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-500">
                    <th className="px-4 py-3">Timestamp</th>
                    <th className="px-4 py-3">Action</th>
                    <th className="px-4 py-3">Module</th>
                    <th className="px-4 py-3">Summary</th>
                    <th className="px-4 py-3 text-right">Result</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {logs.map((entry) => (
                    <tr key={entry.id} className="hover:bg-slate-50/75">
                      <td className="px-4 py-3 font-mono text-xs text-slate-500 tabular-nums whitespace-nowrap">
                        {new Date(entry.createdAt).toLocaleString()}
                      </td>
                      <td className="px-4 py-3 font-mono text-xs font-medium text-slate-800 whitespace-nowrap">
                        {entry.action}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-600 capitalize whitespace-nowrap">
                        {entry.module}
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-700">{entry.summary}</td>
                      <td
                        className={`px-4 py-3 text-right text-xs font-semibold capitalize whitespace-nowrap ${
                          entry.status === 'success'
                            ? 'text-emerald-700'
                            : entry.status === 'denied'
                              ? 'text-amber-700'
                              : 'text-red-700'
                        }`}
                      >
                        {entry.status}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Card Rows */}
            <div className="divide-y divide-slate-100 md:hidden">
              {logs.map((entry) => (
                <div key={entry.id} className="space-y-1.5 p-4">
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-mono font-medium text-slate-800">{entry.action}</span>
                    <span
                      className={`font-semibold capitalize ${
                        entry.status === 'success'
                          ? 'text-emerald-700'
                          : entry.status === 'denied'
                            ? 'text-amber-700'
                            : 'text-red-700'
                      }`}
                    >
                      {entry.status}
                    </span>
                  </div>
                  <p className="text-sm text-slate-700">{entry.summary}</p>
                  <p className="font-mono text-[11px] text-slate-500 tabular-nums">
                    {entry.module} · {new Date(entry.createdAt).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
