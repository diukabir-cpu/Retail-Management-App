import React from 'react';
import { MODULE_MAP } from '../../app/navigation';
import { ModulePlaceholder } from '../../components/ModulePlaceholder';
import type { ModuleId } from '../../types/app';

export const MasterDataView: React.FC<{ onNavigate: (id: ModuleId) => void }> = ({ onNavigate }) => (
  <ModulePlaceholder moduleMeta={MODULE_MAP['master-data']} onNavigate={onNavigate} />
);
export default MasterDataView;
