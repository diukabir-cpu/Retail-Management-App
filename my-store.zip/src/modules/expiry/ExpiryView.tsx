import React from 'react';
import { MODULE_MAP } from '../../app/navigation';
import { ModulePlaceholder } from '../../components/ModulePlaceholder';
import type { ModuleId } from '../../types/app';

export const ExpiryView: React.FC<{ onNavigate: (id: ModuleId) => void }> = ({ onNavigate }) => (
  <ModulePlaceholder moduleMeta={MODULE_MAP.expiry} onNavigate={onNavigate} />
);
export default ExpiryView;
