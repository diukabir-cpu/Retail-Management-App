import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Download, KeyRound, Lock, RotateCcw, Save, ShieldAlert, Upload } from 'lucide-react';
import { ConfirmDialog } from '../../components/ConfirmDialog';
import { StatusAlert } from '../../components/StatusAlert';
import type { AuthChallengeRequest } from '../../hooks/useAdminAuth';
import {
  createBackupPayload,
  parseAndValidateBackupJson,
  restoreDatabaseFromBackup,
  triggerJsonBackupDownload,
} from '../../services/backupService';
import {
  changeAdminPassword,
  getAppSettings,
  setInitialAdminPassword,
  updateAppSettings,
} from '../../services/settingsService';
import type { BackupPayload, BackupValidationResult } from '../../types/app';
import type { AppSettings } from '../../types/database';
import { normalizeError } from '../../utils/errorHandler';
import { validatePasswordStrength } from '../../utils/validation';

interface SettingsViewProps {
  requestAuthorization: (params: Omit<AuthChallengeRequest, 'needsInitialSetup'>) => Promise<void>;
  onSettingsUpdated: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  requestAuthorization,
  onSettingsUpdated,
}) => {
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ tone: 'success' | 'error' | 'info'; message: string } | null>(
    null
  );

  // Store Profile & Threshold form fields
  const [storeName, setStoreName] = useState('MY STORE');
  const [storeSubtitle, setStoreSubtitle] = useState('Retail Management System');
  const [storePhone, setStorePhone] = useState('');
  const [storeAddress, setStoreAddress] = useState('');
  const [invoicePrefix, setInvoicePrefix] = useState('INV');
  const [vatPercent, setVatPercent] = useState('0');
  const [lowStockThreshold, setLowStockThreshold] = useState('10');
  const [expiryWarningDays, setExpiryWarningDays] = useState('30');

  // Password form fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordBusy, setPasswordBusy] = useState(false);

  // Backup & Restore state
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [exportBusy, setExportBusy] = useState(false);
  const [pendingBackupPayload, setPendingBackupPayload] = useState<BackupPayload | null>(null);
  const [pendingValidation, setPendingValidation] = useState<BackupValidationResult | null>(null);
  const [pendingFilename, setPendingFilename] = useState<string | null>(null);
  const [confirmRestoreOpen, setConfirmRestoreOpen] = useState(false);

  const loadSettings = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getAppSettings();
      setSettings(data);
      setStoreName(data.storeName);
      setStoreSubtitle(data.storeSubtitle);
      setStorePhone(data.storePhone);
      setStoreAddress(data.storeAddress);
      setInvoicePrefix(data.invoicePrefix);
      setVatPercent(String(data.defaultVatBasisPoints / 100));
      setLowStockThreshold(String(data.lowStockDefaultThreshold));
      setExpiryWarningDays(String(data.expiryWarningDays));
    } catch (err) {
      setFeedback({ tone: 'error', message: normalizeError(err).userMessage });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadSettings();
  }, [loadSettings]);

  const handleSaveStoreSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    const parsedVat = Math.round(Number(vatPercent) * 100);
    const parsedLowStock = Number(lowStockThreshold);
    const parsedExpiry = Number(expiryWarningDays);

    if (!storeName.trim() || storeName.trim().length < 2) {
      setFeedback({ tone: 'error', message: 'Store name must be at least 2 characters.' });
      return;
    }
    if (!Number.isInteger(parsedVat) || parsedVat < 0 || parsedVat > 10000) {
      setFeedback({ tone: 'error', message: 'Default VAT % must be between 0 and 100.' });
      return;
    }
    if (!Number.isInteger(parsedLowStock) || parsedLowStock < 0) {
      setFeedback({
        tone: 'error',
        message: 'Low stock threshold must be a whole number (0 or greater).',
      });
      return;
    }
    if (!Number.isInteger(parsedExpiry) || parsedExpiry < 1) {
      setFeedback({
        tone: 'error',
        message: 'Expiry warning window must be at least 1 day.',
      });
      return;
    }

    await requestAuthorization({
      action: 'SETTINGS_UPDATE',
      module: 'settings',
      title: 'Authorize Settings Update',
      description: 'Enter the Admin Password to save store configuration changes to IndexedDB.',
      onConfirm: async (adminPassword) => {
        const updated = await updateAppSettings(
          {
            storeName,
            storeSubtitle,
            storePhone,
            storeAddress,
            invoicePrefix,
            defaultVatBasisPoints: parsedVat,
            lowStockDefaultThreshold: parsedLowStock,
            expiryWarningDays: parsedExpiry,
          },
          adminPassword
        );
        setSettings(updated);
        onSettingsUpdated();
        setFeedback({
          tone: 'success',
          message: 'Store settings verified and saved to local IndexedDB.',
        });
      },
    });
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      setFeedback({ tone: 'error', message: strength.message ?? 'Invalid password.' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setFeedback({ tone: 'error', message: 'New password and confirmation do not match.' });
      return;
    }

    setPasswordBusy(true);
    try {
      if (settings?.adminCredential) {
        if (!currentPassword) {
          setFeedback({ tone: 'error', message: 'Enter your current Admin Password.' });
          setPasswordBusy(false);
          return;
        }
        await changeAdminPassword(currentPassword, newPassword);
        setFeedback({
          tone: 'success',
          message: 'Admin Password updated and logged locally.',
        });
      } else {
        await setInitialAdminPassword(newPassword);
        setFeedback({
          tone: 'success',
          message: 'Common Admin Password created and hashed locally with PBKDF2-SHA256.',
        });
      }
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      await loadSettings();
      onSettingsUpdated();
    } catch (err) {
      setFeedback({ tone: 'error', message: normalizeError(err).userMessage });
    } finally {
      setPasswordBusy(false);
    }
  };

  const handleExportBackup = async () => {
    setFeedback(null);
    setExportBusy(true);
    try {
      const payload = await createBackupPayload();
      const filename = triggerJsonBackupDownload(payload);
      await loadSettings();
      setFeedback({
        tone: 'success',
        message: `Backup exported (${payload.recordCount} records across 20 stores) as ${filename}.`,
      });
    } catch (err) {
      setFeedback({ tone: 'error', message: normalizeError(err).userMessage });
    } finally {
      setExportBusy(false);
    }
  };

  const handleBackupFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setFeedback(null);
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const { payload, validation } = parseAndValidateBackupJson(text);
      setPendingFilename(file.name);
      setPendingValidation(validation);
      setPendingBackupPayload(payload);
      if (!validation.valid) {
        setFeedback({
          tone: 'error',
          message: validation.errors[0] ?? 'Selected backup file failed schema validation.',
        });
      }
    } catch (err) {
      setFeedback({ tone: 'error', message: normalizeError(err).userMessage });
      setPendingBackupPayload(null);
      setPendingValidation(null);
    } finally {
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleConfirmRestore = async () => {
    if (!pendingBackupPayload) return;
    setConfirmRestoreOpen(false);

    if (settings?.adminCredential) {
      await requestAuthorization({
        action: 'BACKUP_RESTORE',
        module: 'settings',
        title: 'Authorize Database Restore',
        description: `Enter your Admin Password to overwrite local IndexedDB stores with ${pendingBackupPayload.recordCount} records from backup.`,
        onConfirm: async (adminPassword) => {
          const result = await restoreDatabaseFromBackup(pendingBackupPayload, adminPassword);
          setPendingBackupPayload(null);
          setPendingValidation(null);
          setPendingFilename(null);
          await loadSettings();
          onSettingsUpdated();
          setFeedback({
            tone: 'success',
            message: `Database restored cleanly (${result.restoredRecords} records imported).`,
          });
        },
      });
    } else {
      try {
        const result = await restoreDatabaseFromBackup(pendingBackupPayload, '');
        setPendingBackupPayload(null);
        setPendingValidation(null);
        setPendingFilename(null);
        await loadSettings();
        onSettingsUpdated();
        setFeedback({
          tone: 'success',
          message: `Database restored cleanly (${result.restoredRecords} records imported).`,
        });
      } catch (err) {
        setFeedback({ tone: 'error', message: normalizeError(err).userMessage });
      }
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="h-24 animate-pulse rounded-2xl bg-white border border-slate-200" />
        <div className="h-64 animate-pulse rounded-2xl bg-white border border-slate-200" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">Settings & Backup</h2>
        <p className="mt-0.5 text-sm text-slate-500">
          Store profile, operational thresholds, Common Admin Password security, and offline JSON backup.
        </p>
      </div>

      {feedback && (
        <StatusAlert
          tone={feedback.tone}
          message={feedback.message}
          onDismiss={() => setFeedback(null)}
        />
      )}

      {/* Store Profile & Thresholds */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Store Profile & Thresholds
            </h3>
            <p className="text-xs text-slate-500">
              Changes require Common Admin Password authorization and are recorded in Activity Logs.
            </p>
          </div>
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600">
            <Lock className="h-3.5 w-3.5 text-teal-700" aria-hidden="true" />
            Protected
          </span>
        </div>

        <form onSubmit={handleSaveStoreSettings} className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="setting-store-name" className="block text-xs font-medium text-slate-700">
              Store Display Name
            </label>
            <input
              id="setting-store-name"
              type="text"
              value={storeName}
              onChange={(e) => setStoreName(e.target.value)}
              className="mt-1.5 block w-full min-h-[42px] rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="setting-store-subtitle" className="block text-xs font-medium text-slate-700">
              Store Tagline / Branch
            </label>
            <input
              id="setting-store-subtitle"
              type="text"
              value={storeSubtitle}
              onChange={(e) => setStoreSubtitle(e.target.value)}
              className="mt-1.5 block w-full min-h-[42px] rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="setting-store-phone" className="block text-xs font-medium text-slate-700">
              Store Phone Number
            </label>
            <input
              id="setting-store-phone"
              type="tel"
              value={storePhone}
              onChange={(e) => setStorePhone(e.target.value)}
              placeholder="e.g. 01700000000"
              className="mt-1.5 block w-full min-h-[42px] rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="setting-invoice-prefix" className="block text-xs font-medium text-slate-700">
              Invoice Number Prefix
            </label>
            <input
              id="setting-invoice-prefix"
              type="text"
              maxLength={10}
              value={invoicePrefix}
              onChange={(e) => setInvoicePrefix(e.target.value)}
              className="mt-1.5 block w-full min-h-[42px] rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
            />
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="setting-store-address" className="block text-xs font-medium text-slate-700">
              Store Address
            </label>
            <input
              id="setting-store-address"
              type="text"
              value={storeAddress}
              onChange={(e) => setStoreAddress(e.target.value)}
              placeholder="Road, Area, City"
              className="mt-1.5 block w-full min-h-[42px] rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="setting-vat-percent" className="block text-xs font-medium text-slate-700">
              Default VAT Rate (%)
            </label>
            <input
              id="setting-vat-percent"
              type="number"
              step="0.01"
              min="0"
              max="100"
              value={vatPercent}
              onChange={(e) => setVatPercent(e.target.value)}
              className="mt-1.5 block w-full min-h-[42px] rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm tabular-nums text-slate-900 focus:border-teal-700 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="setting-low-stock" className="block text-xs font-medium text-slate-700">
                Low Stock Threshold
              </label>
              <input
                id="setting-low-stock"
                type="number"
                min="0"
                step="1"
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(e.target.value)}
                className="mt-1.5 block w-full min-h-[42px] rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm tabular-nums text-slate-900 focus:border-teal-700 focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="setting-expiry-days" className="block text-xs font-medium text-slate-700">
                Expiry Alert (Days)
              </label>
              <input
                id="setting-expiry-days"
                type="number"
                min="1"
                step="1"
                value={expiryWarningDays}
                onChange={(e) => setExpiryWarningDays(e.target.value)}
                className="mt-1.5 block w-full min-h-[42px] rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm tabular-nums text-slate-900 focus:border-teal-700 focus:outline-none"
              />
            </div>
          </div>

          <div className="sm:col-span-2 flex items-center justify-between gap-4 border-t border-slate-100 pt-4">
            <span className="text-xs text-slate-500">
              Currency locked to BDT ({settings?.currencySymbol ?? '৳'}) in integer poisha
            </span>
            <button
              type="submit"
              className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-800"
            >
              <Save className="h-4 w-4" aria-hidden="true" />
              Save Store Settings
            </button>
          </div>
        </form>
      </section>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Common Admin Password */}
        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <div className="flex items-center gap-2.5">
            <KeyRound className="h-4 w-4 text-teal-700" aria-hidden="true" />
            <h3 className="text-base font-semibold text-slate-900">
              {settings?.adminCredential ? 'Change Admin Password' : 'Create Admin Password'}
            </h3>
          </div>
          <p className="mt-1 text-xs leading-relaxed text-slate-500">
            Protects catalog edits, vendor/customer changes, discounts, cart removals, returns, and restores on this device. Hashed via PBKDF2-SHA256; never stored in plain text.
          </p>

          <form onSubmit={handlePasswordSubmit} className="mt-4 space-y-3.5">
            {settings?.adminCredential && (
              <div>
                <label htmlFor="admin-current-pw" className="block text-xs font-medium text-slate-700">
                  Current Admin Password
                </label>
                <input
                  id="admin-current-pw"
                  type="password"
                  autoComplete="current-password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="mt-1 block w-full min-h-[42px] rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
                />
              </div>
            )}

            <div>
              <label htmlFor="admin-new-pw" className="block text-xs font-medium text-slate-700">
                New Admin Password (min 6 characters)
              </label>
              <input
                id="admin-new-pw"
                type="password"
                autoComplete="new-password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="mt-1 block w-full min-h-[42px] rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="admin-confirm-pw" className="block text-xs font-medium text-slate-700">
                Confirm New Password
              </label>
              <input
                id="admin-confirm-pw"
                type="password"
                autoComplete="new-password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="mt-1 block w-full min-h-[42px] rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
              />
            </div>

            <div className="flex items-start gap-2 pt-1 text-xs leading-relaxed text-slate-500">
              <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-slate-400" aria-hidden="true" />
              <span>
                Local-device authorization only. Always export regular JSON backups because clearing browser storage removes local credentials and data.
              </span>
            </div>

            <button
              type="submit"
              disabled={passwordBusy}
              className="w-full min-h-[44px] rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-50"
            >
              {passwordBusy
                ? 'Hashing & Saving...'
                : settings?.adminCredential
                  ? 'Update Admin Password'
                  : 'Set Admin Password'}
            </button>
          </form>
        </section>

        {/* Backup & Restore */}
        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-base font-semibold text-slate-900">JSON Backup & Restore</h3>
            <span className="font-mono text-xs text-slate-500 tabular-nums">
              Schema v{settings?.schemaVersion ?? 1}
            </span>
          </div>
          <p className="mt-1 text-xs leading-relaxed text-slate-500">
            Export all 20 IndexedDB stores into a versioned JSON snapshot or restore from a validated backup file.
          </p>

          <div className="mt-5 divide-y divide-slate-100 border-t border-slate-100">
            <div className="py-4">
              <p className="text-xs font-semibold text-slate-800">Export Local Database</p>
              <p className="mt-1 text-xs text-slate-500">
                Last backup:{' '}
                <span className="font-mono tabular-nums">
                  {settings?.lastBackupAt
                    ? new Date(settings.lastBackupAt).toLocaleString()
                    : 'Never'}
                </span>
              </p>
              <button
                type="button"
                onClick={() => {
                  void handleExportBackup();
                }}
                disabled={exportBusy}
                className="mt-3 inline-flex w-full min-h-[44px] items-center justify-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-800 disabled:opacity-50"
              >
                <Download className="h-4 w-4" aria-hidden="true" />
                {exportBusy ? 'Exporting Backup...' : 'Download JSON Backup'}
              </button>
            </div>

            <div className="pt-4">
              <p className="text-xs font-semibold text-slate-800">Restore From JSON Backup</p>
              <p className="mt-1 text-xs text-slate-500">
                Select a MY STORE JSON backup file to validate its schema before restoring.
              </p>

              <input
                ref={fileInputRef}
                id="backup-file-input"
                type="file"
                accept=".json,application/json"
                onChange={handleBackupFileSelected}
                className="sr-only"
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="mt-3 inline-flex w-full min-h-[44px] items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50"
              >
                <Upload className="h-4 w-4" aria-hidden="true" />
                Select Backup JSON File
              </button>

              {pendingValidation && (
                <div className="mt-3 space-y-2 border-t border-slate-100 pt-3 text-xs">
                  <p className="font-medium text-slate-800">
                    File: <span className="font-mono">{pendingFilename}</span>
                  </p>
                  {pendingValidation.valid && pendingValidation.summary ? (
                    <>
                      <p className="text-emerald-700 font-medium">
                        Valid backup · Schema v{pendingValidation.summary.schemaVersion} ·{' '}
                        <span className="font-mono tabular-nums">
                          {pendingValidation.summary.totalRecords}
                        </span>{' '}
                        records · Exported{' '}
                        {new Date(pendingValidation.summary.exportedAt).toLocaleString()}
                      </p>
                      <button
                        type="button"
                        onClick={() => setConfirmRestoreOpen(true)}
                        className="mt-2 inline-flex w-full min-h-[44px] items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700"
                      >
                        <RotateCcw className="h-4 w-4" aria-hidden="true" />
                        Restore Database From Backup
                      </button>
                    </>
                  ) : (
                    <ul className="space-y-1 text-red-700">
                      {pendingValidation.errors.map((errText) => (
                        <li key={errText}>• {errText}</li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>
          </div>
        </section>
      </div>

      <ConfirmDialog
        open={confirmRestoreOpen}
        title="Overwrite Local Database?"
        description="Restoring this backup will replace all current records across all 20 IndexedDB stores on this device. Export a current backup first if you want to keep today's state."
        confirmLabel="Yes, Restore Backup"
        tone="danger"
        onConfirm={() => {
          void handleConfirmRestore();
        }}
        onCancel={() => setConfirmRestoreOpen(false)}
      />
    </div>
  );
};
