import React from 'react';
import { MODULE_MAP } from '../../app/navigation';
import { ModulePlaceholder } from '../../components/ModulePlaceholder';
import type { ModuleId } from '../../types/app';

export const PaymentsView: React.FC<{ onNavigate: (id: ModuleId) => void }> = ({ onNavigate }) => (
  <ModulePlaceholder moduleMeta={MODULE_MAP.payments} onNavigate={onNavigate} />
);
export default PaymentsView;
