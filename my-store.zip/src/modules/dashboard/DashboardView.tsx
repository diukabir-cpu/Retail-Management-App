import React, { useCallback, useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CalendarClock,
  CreditCard,
  Database,
  Package,
  RefreshCw,
  ShieldCheck,
  Tag,
  TrendingUp,
  Users,
  Warehouse,
} from 'lucide-react';
import { MODULES } from '../../app/navigation';
import { StatusAlert } from '../../components/StatusAlert';
import { getDashboardSummary, getStoreRecordCounts } from '../../database/databaseService';
import { getAppSettings } from '../../services/settingsService';
import type { DashboardSummary, ModuleId, StoreRecordCounts } from '../../types/app';
import type { AppSettings } from '../../types/database';
import { formatBDT } from '../../utils/currency';
import { normalizeError } from '../../utils/errorHandler';

interface DashboardViewProps {
  onNavigate: (moduleId: ModuleId) => void;
}

const EMPTY_SUMMARY: DashboardSummary = {
  todaySalesPoisha: 0,
  todayInvoiceCount: 0,
  todayDiscountPoisha: 0,
  totalProducts: 0,
  totalStockUnits: 0,
  totalCustomers: 0,
  lowStockProducts: 0,
  expiringProducts: 0,
  vendorOutstandingPoisha: 0,
};

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate }) => {
  const [summary, setSummary] = useState<DashboardSummary>(EMPTY_SUMMARY);
  const [counts, setCounts] = useState<StoreRecordCounts | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const [summaryRes, countsRes, settingsRes] = await Promise.all([
        getDashboardSummary(),
        getStoreRecordCounts(),
        getAppSettings(),
      ]);
      setSummary(summaryRes);
      setCounts(countsRes);
      setSettings(settingsRes);
    } catch (err) {
      setErrorMsg(normalizeError(err).userMessage);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadDashboard();
  }, [loadDashboard]);

  const kpiCards = [
    {
      label: "Today's Sales",
      value: formatBDT(summary.todaySalesPoisha),
      hint: `${summary.todayInvoiceCount} invoice${summary.todayInvoiceCount === 1 ? '' : 's'} today`,
      icon: TrendingUp,
      tone: 'text-teal-700 bg-teal-50',
    },
    {
      label: 'Total Products',
      value: summary.totalProducts.toLocaleString('en-US'),
      hint: 'Active & archived SKUs',
      icon: Package,
      tone: 'text-slate-700 bg-slate-100',
    },
    {
      label: 'Total Stock',
      value: summary.totalStockUnits.toLocaleString('en-US'),
      hint: 'Units across batches',
      icon: Warehouse,
      tone: 'text-slate-700 bg-slate-100',
    },
    {
      label: 'Total Customers',
      value: summary.totalCustomers.toLocaleString('en-US'),
      hint: 'Registered profiles',
      icon: Users,
      tone: 'text-slate-700 bg-slate-100',
    },
    {
      label: 'Low Stock Products',
      value: summary.lowStockProducts.toLocaleString('en-US'),
      hint: `Threshold <= ${settings?.lowStockDefaultThreshold ?? 10} units`,
      icon: AlertTriangle,
      tone: summary.lowStockProducts > 0 ? 'text-amber-700 bg-amber-50' : 'text-slate-700 bg-slate-100',
    },
    {
      label: 'Expiring Products',
      value: summary.expiringProducts.toLocaleString('en-US'),
      hint: `Within ${settings?.expiryWarningDays ?? 30} days`,
      icon: CalendarClock,
      tone: summary.expiringProducts > 0 ? 'text-red-700 bg-red-50' : 'text-slate-700 bg-slate-100',
    },
    {
      label: "Today's Discount",
      value: formatBDT(summary.todayDiscountPoisha),
      hint: 'POS & member discounts',
      icon: Tag,
      tone: 'text-slate-700 bg-slate-100',
    },
    {
      label: 'Vendor Outstanding',
      value: formatBDT(summary.vendorOutstandingPoisha),
      hint: 'Total supplier payables',
      icon: CreditCard,
      tone:
        summary.vendorOutstandingPoisha > 0
          ? 'text-amber-700 bg-amber-50'
          : 'text-slate-700 bg-slate-100',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Row */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 sm:text-2xl">
            Store Overview
          </h2>
          <p className="mt-0.5 text-sm text-slate-500">
            Live local IndexedDB snapshot · Currency BDT (৳) · No sample transactions
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              void loadDashboard();
            }}
            disabled={loading}
            className="inline-flex min-h-[42px] items-center gap-2 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50 disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} aria-hidden="true" />
            Refresh
          </button>
          <button
            type="button"
            onClick={() => onNavigate('settings')}
            className="inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-teal-800"
          >
            Store Settings
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </div>

      {errorMsg && <StatusAlert tone="error" message={errorMsg} />}

      {/* 8 Summary KPI Cards */}
      <section aria-label="Key store metrics">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {kpiCards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.label}
                className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-5"
              >
                <div className="flex items-start justify-between gap-3">
                  <span className="text-xs font-medium text-slate-500">{card.label}</span>
                  <div
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${card.tone}`}
                  >
                    <Icon className="h-4 w-4" aria-hidden="true" />
                  </div>
                </div>

                <div className="mt-3">
                  {loading ? (
                    <div className="h-8 w-28 animate-pulse rounded-md bg-slate-100" />
                  ) : (
                    <p
                      data-testid={`kpi-${card.label.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}
                      className="font-mono text-2xl font-semibold tracking-tight tabular-nums text-slate-900"
                    >
                      {card.value}
                    </p>
                  )}
                  <p className="mt-1 text-xs text-slate-500">{card.hint}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Two-Column System Foundation & Empty State Guidance */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <section className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-2">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                Retail Modules Directory
              </h3>
              <p className="mt-0.5 text-xs text-slate-500">
                16-module navigation shell wired to 20 versioned IndexedDB stores.
              </p>
            </div>
            <span className="font-mono text-xs text-slate-500 tabular-nums">
              {MODULES.length} modules
            </span>
          </div>

          <div className="mt-4 divide-y divide-slate-100 border-t border-slate-100">
            {MODULES.map((mod) => (
              <div
                key={mod.id}
                className="flex items-center justify-between gap-4 py-3 text-sm"
              >
                <div className="min-w-0">
                  <button
                    type="button"
                    onClick={() => onNavigate(mod.id)}
                    className="font-medium text-slate-900 hover:text-teal-700 focus-visible:outline-2 focus-visible:outline-teal-700"
                  >
                    {mod.label}
                  </button>
                  <p className="truncate text-xs text-slate-500">{mod.description}</p>
                </div>
                <span
                  className={`shrink-0 text-xs font-medium ${
                    mod.phaseStatus === 'active' ? 'text-teal-700' : 'text-slate-500'
                  }`}
                >
                  {mod.phaseStatus === 'active' ? 'Active' : 'Phase 2+'}
                </span>
              </div>
            ))}
          </div>
        </section>

        <aside className="space-y-6">
          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex items-center gap-2.5">
              <Database className="h-4 w-4 text-teal-700" aria-hidden="true" />
              <h3 className="text-base font-semibold text-slate-900">Local Database Status</h3>
            </div>
            <dl className="mt-4 space-y-3 text-sm">
              <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
                <dt className="text-slate-500">Storage Engine</dt>
                <dd className="font-medium text-slate-900">IndexedDB (Dexie.js)</dd>
              </div>
              <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
                <dt className="text-slate-500">Schema Version</dt>
                <dd className="font-mono text-slate-900 tabular-nums">
                  v{settings?.schemaVersion ?? 1}
                </dd>
              </div>
              <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
                <dt className="text-slate-500">Database Stores</dt>
                <dd className="font-mono text-slate-900 tabular-nums">20 tables</dd>
              </div>
              <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
                <dt className="text-slate-500">Activity Log Entries</dt>
                <dd className="font-mono text-slate-900 tabular-nums">
                  {counts?.activityLogs ?? 0}
                </dd>
              </div>
              <div className="flex items-center justify-between gap-2">
                <dt className="text-slate-500">Last JSON Backup</dt>
                <dd className="font-mono text-xs text-slate-700 tabular-nums">
                  {settings?.lastBackupAt
                    ? new Date(settings.lastBackupAt).toLocaleDateString()
                    : 'Not yet backed up'}
                </dd>
              </div>
            </dl>
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="h-4 w-4 text-teal-700" aria-hidden="true" />
              <h3 className="text-base font-semibold text-slate-900">Security & Audit</h3>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-slate-600">
              {settings?.adminCredential
                ? 'Common Admin Password is active. Sensitive store actions require verification and are recorded in Activity Logs.'
                : 'No Admin Password is set yet. Configure one in Settings to protect store configuration, backups, and inventory mutations.'}
            </p>
            <div className="mt-4 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => onNavigate('settings')}
                className="w-full min-h-[42px] rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50"
              >
                {settings?.adminCredential ? 'Manage Security & Backup' : 'Set Admin Password'}
              </button>
              <button
                type="button"
                onClick={() => onNavigate('activity-logs')}
                className="w-full min-h-[42px] rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50"
              >
                Inspect Activity Logs
              </button>
            </div>
          </section>
        </aside>
      </div>
    </div>
  );
};
