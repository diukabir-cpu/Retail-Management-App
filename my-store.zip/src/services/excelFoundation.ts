/**
 * Excel-compatible CSV export foundation for Phase 2+ modules
 * (Master Excel / Data Management & Reports).
 * Includes UTF-8 BOM so BDT currency symbol (৳) renders cleanly in Excel.
 */

function escapeCsvCell(value: string | number | boolean | null | undefined): string {
  if (value === null || value === undefined) {
    return '';
  }
  const str = String(value);
  if (/[",\r\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function buildExcelCsvDocument(
  headers: readonly string[],
  rows: readonly (readonly (string | number | boolean | null | undefined)[])[]
): string {
  const headerLine = headers.map(escapeCsvCell).join(',');
  const dataLines = rows.map((row) => row.map(escapeCsvCell).join(','));
  const content = [headerLine, ...dataLines].join('\r\n');
  return `\uFEFF${content}`;
}
