import { db, initializeDatabase, type MyStoreDatabase } from '../database/db';
import type { ActivityLog } from '../types/database';
import { generateId } from '../utils/id';
import { normalizeError } from '../utils/errorHandler';

export interface CreateActivityLogInput {
  action: ActivityLog['action'];
  module: string;
  summary: string;
  entityId?: string;
  status: ActivityLog['status'];
  metadata?: Record<string, string | number | boolean>;
}

export interface ActivityLogQueryOptions {
  search?: string;
  status?: 'all' | ActivityLog['status'];
  limit?: number;
}

export async function recordActivity(
  input: CreateActivityLogInput,
  database: MyStoreDatabase = db
): Promise<ActivityLog> {
  try {
    await initializeDatabase(database);
    const entry: ActivityLog = {
      id: generateId('log'),
      action: input.action,
      module: input.module,
      summary: input.summary,
      entityId: input.entityId,
      status: input.status,
      metadata: input.metadata,
      createdAt: new Date().toISOString(),
    };
    await database.activityLogs.add(entry);
    return entry;
  } catch (error) {
    throw normalizeError(error);
  }
}

export async function queryActivityLogs(
  options: ActivityLogQueryOptions = {},
  database: MyStoreDatabase = db
): Promise<ActivityLog[]> {
  try {
    await initializeDatabase(database);
    const { search = '', status = 'all', limit = 100 } = options;
    const trimmedSearch = search.trim().toLowerCase();

    let collection = database.activityLogs.orderBy('createdAt').reverse();

    if (status !== 'all' || trimmedSearch.length > 0) {
      collection = collection.filter((entry) => {
        if (status !== 'all' && entry.status !== status) {
          return false;
        }
        if (trimmedSearch.length > 0) {
          const haystack = `${entry.action} ${entry.module} ${entry.summary}`.toLowerCase();
          return haystack.includes(trimmedSearch);
        }
        return true;
      });
    }

    return await collection.limit(limit).toArray();
  } catch (error) {
    throw normalizeError(error);
  }
}
