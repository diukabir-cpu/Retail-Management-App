import test from 'node:test';
import assert from 'node:assert/strict';
import { hashAdminPassword, verifyAdminPassword } from './cryptoService';

test('hashAdminPassword produces salted PBKDF2-SHA256 hash and verifies correctly', async () => {
  const credentialA = await hashAdminPassword('Store@2026');
  const credentialB = await hashAdminPassword('Store@2026');

  assert.equal(credentialA.algorithm, 'PBKDF2-SHA256');
  assert.equal(credentialA.iterations, 100_000);
  assert.notEqual(credentialA.saltHex, credentialB.saltHex);
  assert.notEqual(credentialA.hashHex, credentialB.hashHex);

  assert.equal(await verifyAdminPassword('Store@2026', credentialA), true);
  assert.equal(await verifyAdminPassword('Store@2026', credentialB), true);
  assert.equal(await verifyAdminPassword('WrongPassword', credentialA), false);
  assert.equal(await verifyAdminPassword('', credentialA), false);
});

test('verifyAdminPassword rejects tampered hash', async () => {
  const credential = await hashAdminPassword('Secret#99');
  const tampered = {
    ...credential,
    hashHex: '0'.repeat(credential.hashHex.length),
  };
  assert.equal(await verifyAdminPassword('Secret#99', tampered), false);
});
