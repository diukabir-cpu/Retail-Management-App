import type { AdminCredentialHash } from '../types/database';
import { AppError } from '../utils/errorHandler';

const PBKDF2_ITERATIONS = 100_000;
const SALT_BYTES = 16;
const DERIVED_KEY_BITS = 256;

function getWebCrypto(): Crypto {
  const cryptoApi = globalThis.crypto;
  if (!cryptoApi || !cryptoApi.subtle) {
    throw new AppError(
      'AUTHORIZATION_ERROR',
      'Secure browser cryptography (Web Crypto API) is unavailable in this context.'
    );
  }
  return cryptoApi;
}

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}

function hexToBytes(hex: string): Uint8Array {
  if (hex.length % 2 !== 0 || !/^[0-9a-fA-F]*$/.test(hex)) {
    throw new AppError('AUTHORIZATION_ERROR', 'Stored credential hash format is invalid.');
  }
  const result = new Uint8Array(hex.length / 2);
  for (let i = 0; i < result.length; i += 1) {
    result[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  return result;
}

function constantTimeEqualHex(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

async function derivePbkdf2Hex(
  password: string,
  salt: Uint8Array,
  iterations: number
): Promise<string> {
  const cryptoApi = getWebCrypto();
  const encoder = new TextEncoder();
  const passwordBytes = encoder.encode(password);

  const keyMaterial = await cryptoApi.subtle.importKey(
    'raw',
    passwordBytes,
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );

  // Copy salt into a fresh ArrayBuffer-backed Uint8Array for strict TS BufferSource compatibility
  const saltBuffer = new Uint8Array(salt.byteLength);
  saltBuffer.set(salt);

  const derivedBits = await cryptoApi.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: saltBuffer,
      iterations,
      hash: 'SHA-256',
    },
    keyMaterial,
    DERIVED_KEY_BITS
  );

  return bytesToHex(new Uint8Array(derivedBits));
}

export async function hashAdminPassword(password: string): Promise<AdminCredentialHash> {
  const cryptoApi = getWebCrypto();
  const salt = new Uint8Array(SALT_BYTES);
  cryptoApi.getRandomValues(salt);

  const hashHex = await derivePbkdf2Hex(password, salt, PBKDF2_ITERATIONS);

  return {
    algorithm: 'PBKDF2-SHA256',
    iterations: PBKDF2_ITERATIONS,
    saltHex: bytesToHex(salt),
    hashHex,
    updatedAt: new Date().toISOString(),
  };
}

export async function verifyAdminPassword(
  password: string,
  credential: AdminCredentialHash
): Promise<boolean> {
  if (!password || !credential || credential.algorithm !== 'PBKDF2-SHA256') {
    return false;
  }

  const salt = hexToBytes(credential.saltHex);
  const candidateHex = await derivePbkdf2Hex(password, salt, credential.iterations);
  return constantTimeEqualHex(candidateHex, credential.hashHex);
}
