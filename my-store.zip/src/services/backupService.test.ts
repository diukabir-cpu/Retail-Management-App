import test from 'node:test';
import assert from 'node:assert/strict';
import { STORE_NAMES } from '../database/schema';
import { parseAndValidateBackupJson, validateBackupPayload } from './backupService';

function createValidBackupObject() {
  const tables: Record<string, unknown[]> = {};
  for (const name of STORE_NAMES) {
    tables[name] = [];
  }
  tables.settings = [{ id: 'default', storeName: 'MY STORE' }];

  return {
    appName: 'MY STORE',
    backupFormatVersion: 1,
    schemaVersion: 1,
    exportedAt: '2026-11-18T10:00:00.000Z',
    recordCount: 1,
    tables,
  };
}

test('validateBackupPayload accepts valid 20-store backup payload', () => {
  const payload = createValidBackupObject();
  const result = validateBackupPayload(payload);

  assert.equal(result.valid, true);
  assert.equal(result.errors.length, 0);
  assert.equal(result.summary?.totalRecords, 1);
  assert.equal(result.summary?.schemaVersion, 1);
});

test('validateBackupPayload rejects mismatched appName and future schema versions', () => {
  const badApp = { ...createValidBackupObject(), appName: 'OTHER APP' };
  const res1 = validateBackupPayload(badApp);
  assert.equal(res1.valid, false);
  assert.ok(res1.errors.some((e) => e.includes('appName')));

  const futureSchema = { ...createValidBackupObject(), schemaVersion: 99 };
  const res2 = validateBackupPayload(futureSchema);
  assert.equal(res2.valid, false);
  assert.ok(res2.errors.some((e) => e.includes('schemaVersion') || e.includes('newer')));
});

test('validateBackupPayload rejects duplicate IDs inside a table', () => {
  const payload = createValidBackupObject();
  payload.tables.categories = [
    { id: 'cat_1', name: 'Beverages' },
    { id: 'cat_1', name: 'Snacks' },
  ];
  payload.recordCount = 3;

  const result = validateBackupPayload(payload);
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes('Duplicate ID')));
});

test('parseAndValidateBackupJson catches malformed JSON safely', () => {
  const { payload, validation } = parseAndValidateBackupJson('{ invalid json');
  assert.equal(payload, null);
  assert.equal(validation.valid, false);
  assert.ok(validation.errors[0].includes('valid JSON'));
});
