import { db, initializeDatabase, type MyStoreDatabase } from '../database/db';
import { createDefaultSettings } from '../database/schema';
import type { AppSettings, ProtectedActionType } from '../types/database';
import { AppError, normalizeError } from '../utils/errorHandler';
import { generateId } from '../utils/id';
import { validatePasswordStrength } from '../utils/validation';
import { hashAdminPassword, verifyAdminPassword } from './cryptoService';

export interface SettingsUpdatePatch {
  storeName?: string;
  storeSubtitle?: string;
  storePhone?: string;
  storeAddress?: string;
  defaultVatBasisPoints?: number;
  lowStockDefaultThreshold?: number;
  expiryWarningDays?: number;
  invoicePrefix?: string;
}

export async function getAppSettings(database: MyStoreDatabase = db): Promise<AppSettings> {
  try {
    await initializeDatabase(database);
    const settings = await database.settings.get('default');
    return settings ?? createDefaultSettings();
  } catch (error) {
    throw normalizeError(error);
  }
}

export async function isAdminPasswordConfigured(database: MyStoreDatabase = db): Promise<boolean> {
  const settings = await getAppSettings(database);
  return settings.adminCredential !== null;
}

export async function setInitialAdminPassword(
  password: string,
  database: MyStoreDatabase = db
): Promise<void> {
  const strength = validatePasswordStrength(password);
  if (!strength.valid) {
    throw new AppError('VALIDATION_ERROR', strength.message ?? 'Invalid admin password.');
  }

  try {
    await initializeDatabase(database);
    const credential = await hashAdminPassword(password);
    const nowISO = new Date().toISOString();

    await database.transaction('rw', database.settings, database.activityLogs, async () => {
      const current = (await database.settings.get('default')) ?? createDefaultSettings(nowISO);
      if (current.adminCredential !== null) {
        throw new AppError(
          'AUTHORIZATION_ERROR',
          'An admin password is already configured. Use Change Password instead.'
        );
      }

      await database.settings.put({
        ...current,
        adminCredential: credential,
        updatedAt: nowISO,
      });

      await database.activityLogs.add({
        id: generateId('log'),
        action: 'ADMIN_PASSWORD_SET',
        module: 'settings',
        summary: 'Common Admin Password was configured for local protected actions.',
        status: 'success',
        createdAt: nowISO,
      });
    });
  } catch (error) {
    throw normalizeError(error);
  }
}

export async function changeAdminPassword(
  currentPassword: string,
  newPassword: string,
  database: MyStoreDatabase = db
): Promise<void> {
  const strength = validatePasswordStrength(newPassword);
  if (!strength.valid) {
    throw new AppError('VALIDATION_ERROR', strength.message ?? 'Invalid new admin password.');
  }

  try {
    await initializeDatabase(database);
    const current = await database.settings.get('default');
    if (!current?.adminCredential) {
      throw new AppError('AUTHORIZATION_ERROR', 'Admin password is not configured yet.');
    }

    const isMatch = await verifyAdminPassword(currentPassword, current.adminCredential);
    const nowISO = new Date().toISOString();

    if (!isMatch) {
      await database.activityLogs.add({
        id: generateId('log'),
        action: 'AUTH_FAILED',
        module: 'settings',
        summary: 'Failed Admin Password change attempt due to incorrect current password.',
        status: 'denied',
        createdAt: nowISO,
      });
      throw new AppError('AUTHORIZATION_ERROR', 'Current admin password is incorrect.');
    }

    const newCredential = await hashAdminPassword(newPassword);

    await database.transaction('rw', database.settings, database.activityLogs, async () => {
      const latest = (await database.settings.get('default')) ?? current;
      await database.settings.put({
        ...latest,
        adminCredential: newCredential,
        updatedAt: nowISO,
      });
      await database.activityLogs.add({
        id: generateId('log'),
        action: 'ADMIN_PASSWORD_CHANGE',
        module: 'settings',
        summary: 'Common Admin Password was changed.',
        status: 'success',
        createdAt: nowISO,
      });
    });
  } catch (error) {
    throw normalizeError(error);
  }
}

export async function verifyAndAuthorizeAction(
  password: string,
  action: ProtectedActionType,
  module: string,
  summary: string,
  database: MyStoreDatabase = db
): Promise<boolean> {
  try {
    await initializeDatabase(database);
    const settings = await database.settings.get('default');
    if (!settings?.adminCredential) {
      throw new AppError(
        'AUTHORIZATION_ERROR',
        'No Admin Password is set yet. Create an Admin Password first.'
      );
    }

    const valid = await verifyAdminPassword(password, settings.adminCredential);
    const nowISO = new Date().toISOString();

    await database.activityLogs.add({
      id: generateId('log'),
      action: valid ? action : 'AUTH_FAILED',
      module,
      summary: valid ? summary : `Authorization denied for ${action} in ${module}.`,
      status: valid ? 'success' : 'denied',
      createdAt: nowISO,
    });

    if (!valid) {
      throw new AppError('AUTHORIZATION_ERROR', 'Incorrect Admin Password. Action was not authorized.');
    }

    return true;
  } catch (error) {
    throw normalizeError(error);
  }
}

export async function updateAppSettings(
  patch: SettingsUpdatePatch,
  adminPassword: string,
  database: MyStoreDatabase = db
): Promise<AppSettings> {
  if (patch.storeName !== undefined && patch.storeName.trim().length < 2) {
    throw new AppError('VALIDATION_ERROR', 'Store name must be at least 2 characters.');
  }
  if (
    patch.lowStockDefaultThreshold !== undefined &&
    (!Number.isInteger(patch.lowStockDefaultThreshold) || patch.lowStockDefaultThreshold < 0)
  ) {
    throw new AppError('VALIDATION_ERROR', 'Low stock threshold must be a whole non-negative number.');
  }
  if (
    patch.expiryWarningDays !== undefined &&
    (!Number.isInteger(patch.expiryWarningDays) || patch.expiryWarningDays < 1)
  ) {
    throw new AppError('VALIDATION_ERROR', 'Expiry warning days must be at least 1.');
  }
  if (
    patch.defaultVatBasisPoints !== undefined &&
    (!Number.isInteger(patch.defaultVatBasisPoints) ||
      patch.defaultVatBasisPoints < 0 ||
      patch.defaultVatBasisPoints > 10000)
  ) {
    throw new AppError('VALIDATION_ERROR', 'Default VAT rate must be between 0% and 100%.');
  }

  await verifyAndAuthorizeAction(
    adminPassword,
    'SETTINGS_UPDATE',
    'settings',
    'Updated store configuration and operational thresholds.',
    database
  );

  try {
    const nowISO = new Date().toISOString();
    let updated!: AppSettings;

    await database.transaction('rw', database.settings, async () => {
      const current = (await database.settings.get('default')) ?? createDefaultSettings(nowISO);
      updated = {
        ...current,
        storeName: patch.storeName !== undefined ? patch.storeName.trim() : current.storeName,
        storeSubtitle:
          patch.storeSubtitle !== undefined ? patch.storeSubtitle.trim() : current.storeSubtitle,
        storePhone: patch.storePhone !== undefined ? patch.storePhone.trim() : current.storePhone,
        storeAddress:
          patch.storeAddress !== undefined ? patch.storeAddress.trim() : current.storeAddress,
        defaultVatBasisPoints:
          patch.defaultVatBasisPoints !== undefined
            ? patch.defaultVatBasisPoints
            : current.defaultVatBasisPoints,
        lowStockDefaultThreshold:
          patch.lowStockDefaultThreshold !== undefined
            ? patch.lowStockDefaultThreshold
            : current.lowStockDefaultThreshold,
        expiryWarningDays:
          patch.expiryWarningDays !== undefined
            ? patch.expiryWarningDays
            : current.expiryWarningDays,
        invoicePrefix:
          patch.invoicePrefix !== undefined
            ? patch.invoicePrefix.trim().toUpperCase() || 'INV'
            : current.invoicePrefix,
        updatedAt: nowISO,
      };
      await database.settings.put(updated);
    });

    return updated;
  } catch (error) {
    throw normalizeError(error);
  }
}
