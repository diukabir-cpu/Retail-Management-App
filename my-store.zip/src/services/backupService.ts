import { db, initializeDatabase, type MyStoreDatabase } from '../database/db';
import {
  BACKUP_FORMAT_VERSION,
  CURRENT_SCHEMA_VERSION,
  STORE_NAMES,
  type StoreName,
} from '../database/schema';
import type { BackupPayload, BackupTableData, BackupValidationResult } from '../types/app';
import { AppError, normalizeError } from '../utils/errorHandler';
import { generateId } from '../utils/id';
import { verifyAndAuthorizeAction } from './settingsService';

export function validateBackupPayload(input: unknown): BackupValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    return {
      valid: false,
      errors: ['Backup file must contain a valid JSON object.'],
      warnings,
    };
  }

  const candidate = input as Record<string, unknown>;

  if (candidate.appName !== 'MY STORE') {
    errors.push('Backup file does not belong to MY STORE ("appName" mismatch).');
  }

  if (
    typeof candidate.backupFormatVersion !== 'number' ||
    !Number.isInteger(candidate.backupFormatVersion) ||
    candidate.backupFormatVersion < 1
  ) {
    errors.push('Invalid or missing "backupFormatVersion".');
  } else if (candidate.backupFormatVersion > BACKUP_FORMAT_VERSION) {
    errors.push(
      `Backup format v${candidate.backupFormatVersion} is newer than this app supports (v${BACKUP_FORMAT_VERSION}).`
    );
  }

  if (
    typeof candidate.schemaVersion !== 'number' ||
    !Number.isInteger(candidate.schemaVersion) ||
    candidate.schemaVersion < 1
  ) {
    errors.push('Invalid or missing "schemaVersion".');
  } else if (candidate.schemaVersion > CURRENT_SCHEMA_VERSION) {
    errors.push(
      `Backup database schema v${candidate.schemaVersion} is newer than current schema v${CURRENT_SCHEMA_VERSION}.`
    );
  }

  if (typeof candidate.exportedAt !== 'string' || Number.isNaN(Date.parse(candidate.exportedAt))) {
    errors.push('Invalid or missing "exportedAt" timestamp.');
  }

  if (!candidate.tables || typeof candidate.tables !== 'object' || Array.isArray(candidate.tables)) {
    errors.push('Backup file is missing the "tables" object.');
    return { valid: false, errors, warnings };
  }

  const tablesObj = candidate.tables as Record<string, unknown>;
  const tableCounts: Record<string, number> = {};
  let totalRecords = 0;

  for (const storeName of STORE_NAMES) {
    const rows = tablesObj[storeName];
    if (!Array.isArray(rows)) {
      errors.push(`Missing or invalid table array for "${storeName}".`);
      continue;
    }

    const seenIds = new Set<string>();
    for (let idx = 0; idx < rows.length; idx += 1) {
      const row = rows[idx];
      if (!row || typeof row !== 'object' || Array.isArray(row)) {
        errors.push(`Invalid record in "${storeName}" at index ${idx}.`);
        break;
      }
      const recordId = (row as Record<string, unknown>).id;
      if (typeof recordId !== 'string' || recordId.trim().length === 0) {
        errors.push(`Record in "${storeName}" at index ${idx} is missing a valid string "id".`);
        break;
      }
      if (seenIds.has(recordId)) {
        errors.push(`Duplicate ID "${recordId}" found in backup table "${storeName}".`);
        break;
      }
      seenIds.add(recordId);
    }

    tableCounts[storeName] = rows.length;
    totalRecords += rows.length;
  }

  if (typeof candidate.recordCount === 'number' && candidate.recordCount !== totalRecords) {
    warnings.push(
      `Declared recordCount (${candidate.recordCount}) differs from counted records (${totalRecords}).`
    );
  }

  if (errors.length > 0) {
    return { valid: false, errors, warnings };
  }

  return {
    valid: true,
    errors: [],
    warnings,
    summary: {
      schemaVersion: candidate.schemaVersion as number,
      exportedAt: candidate.exportedAt as string,
      totalRecords,
      tableCounts,
    },
  };
}

export function parseAndValidateBackupJson(jsonText: string): {
  payload: BackupPayload | null;
  validation: BackupValidationResult;
} {
  let parsed: unknown;
  try {
    parsed = JSON.parse(jsonText);
  } catch {
    return {
      payload: null,
      validation: {
        valid: false,
        errors: ['The selected file is not valid JSON.'],
        warnings: [],
      },
    };
  }

  const validation = validateBackupPayload(parsed);
  return {
    payload: validation.valid ? (parsed as BackupPayload) : null,
    validation,
  };
}

export async function createBackupPayload(database: MyStoreDatabase = db): Promise<BackupPayload> {
  try {
    await initializeDatabase(database);
    const tables = {} as BackupTableData;
    let recordCount = 0;

    await database.transaction('r', database.tables, async () => {
      for (const storeName of STORE_NAMES) {
        const rows = await database.table(storeName).toArray();
        tables[storeName] = rows;
        recordCount += rows.length;
      }
    });

    const exportedAt = new Date().toISOString();

    await database.transaction('rw', database.settings, database.activityLogs, async () => {
      const settings = await database.settings.get('default');
      if (settings) {
        await database.settings.put({
          ...settings,
          lastBackupAt: exportedAt,
          updatedAt: exportedAt,
        });
      }
      await database.activityLogs.add({
        id: generateId('log'),
        action: 'BACKUP_EXPORT',
        module: 'settings',
        summary: `Exported full JSON backup (${recordCount} records across ${STORE_NAMES.length} stores).`,
        status: 'success',
        metadata: {
          recordCount,
          schemaVersion: CURRENT_SCHEMA_VERSION,
        },
        createdAt: exportedAt,
      });
    });

    return {
      appName: 'MY STORE',
      backupFormatVersion: BACKUP_FORMAT_VERSION,
      schemaVersion: CURRENT_SCHEMA_VERSION,
      exportedAt,
      recordCount,
      tables,
    };
  } catch (error) {
    throw normalizeError(error);
  }
}

export function triggerJsonBackupDownload(payload: BackupPayload): string {
  const dateStamp = payload.exportedAt.slice(0, 19).replace(/[:T]/g, '-');
  const filename = `my-store-backup-v${payload.schemaVersion}-${dateStamp}.json`;
  const json = JSON.stringify(payload, null, 2);
  const blob = new Blob([json], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  return filename;
}

export async function restoreDatabaseFromBackup(
  payload: BackupPayload,
  adminPassword: string,
  database: MyStoreDatabase = db
): Promise<{ restoredRecords: number }> {
  const validation = validateBackupPayload(payload);
  if (!validation.valid) {
    throw new AppError(
      'BACKUP_ERROR',
      validation.errors[0] ?? 'Backup validation failed.'
    );
  }

  // Require Admin Password authorization when an admin credential exists in the current DB.
  const currentSettings = await database.settings.get('default');
  if (currentSettings?.adminCredential) {
    await verifyAndAuthorizeAction(
      adminPassword,
      'BACKUP_RESTORE',
      'settings',
      `Authorized database restore from backup exported at ${payload.exportedAt}.`,
      database
    );
  }

  try {
    let restoredRecords = 0;
    const nowISO = new Date().toISOString();

    await database.transaction('rw', database.tables, async () => {
      for (const storeName of STORE_NAMES) {
        const table = database.table(storeName as StoreName);
        await table.clear();
        const rows = payload.tables[storeName as StoreName];
        if (rows.length > 0) {
          await table.bulkAdd(rows);
          restoredRecords += rows.length;
        }
      }

      await database.activityLogs.add({
        id: generateId('log'),
        action: 'BACKUP_RESTORE',
        module: 'settings',
        summary: `Restored ${restoredRecords} records from backup exported on ${payload.exportedAt}.`,
        status: 'success',
        metadata: {
          restoredRecords,
          backupSchemaVersion: payload.schemaVersion,
        },
        createdAt: nowISO,
      });
    });

    return { restoredRecords };
  } catch (error) {
    throw normalizeError(error);
  }
}
