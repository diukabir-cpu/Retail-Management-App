import React, { useMemo, useState } from 'react';
import { Menu, Search, ShieldCheck, Store, X } from 'lucide-react';
import { MODULE_MAP, MODULES, NAV_GROUP_LABELS } from '../app/navigation';
import { ConnectivityBadge, OfflineBanner } from '../components/ConnectivityStatus';
import { ModuleIcon } from '../components/ModuleIcon';
import { PWAInstallButton } from '../components/PWAInstallButton';
import type { ModuleId, NavGroup } from '../types/app';

interface AppShellProps {
  activeModule: ModuleId;
  storeName: string;
  adminConfigured: boolean;
  onSelectModule: (moduleId: ModuleId) => void;
  children: React.ReactNode;
}

const NAV_GROUPS: NavGroup[] = ['operations', 'inventory', 'people', 'system'];
const MOBILE_PRIMARY_TABS: ModuleId[] = ['dashboard', 'pos', 'products', 'settings'];

export const AppShell: React.FC<AppShellProps> = ({
  activeModule,
  storeName,
  adminConfigured,
  onSelectModule,
  children,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [navFilter, setNavFilter] = useState('');

  const activeMeta = MODULE_MAP[activeModule];

  const filteredModules = useMemo(() => {
    const query = navFilter.trim().toLowerCase();
    if (!query) return MODULES;
    return MODULES.filter((m) => m.label.toLowerCase().includes(query));
  }, [navFilter]);

  const handleSelect = (id: ModuleId) => {
    onSelectModule(id);
    setMobileMenuOpen(false);
  };

  const renderNavGroups = () => (
    <div className="space-y-5">
      {NAV_GROUPS.map((group) => {
        const groupItems = filteredModules.filter((m) => m.group === group);
        if (groupItems.length === 0) return null;

        return (
          <div key={group}>
            <p className="px-3 text-xs font-semibold text-slate-400">
              {NAV_GROUP_LABELS[group]}
            </p>
            <ul className="mt-1.5 space-y-0.5">
              {groupItems.map((item) => {
                const isActive = item.id === activeModule;
                return (
                  <li key={item.id}>
                    <button
                      type="button"
                      onClick={() => handleSelect(item.id)}
                      aria-current={isActive ? 'page' : undefined}
                      className={`flex w-full min-h-[40px] items-center justify-between gap-2.5 rounded-lg px-3 py-2 text-left text-sm transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 ${
                        isActive
                          ? 'bg-teal-50 font-semibold text-teal-800'
                          : 'font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      <span className="flex min-w-0 items-center gap-2.5">
                        <ModuleIcon
                          moduleId={item.id}
                          className={`h-4 w-4 shrink-0 ${
                            isActive ? 'text-teal-700' : 'text-slate-400'
                          }`}
                        />
                        <span className="truncate">{item.label}</span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        );
      })}
      {filteredModules.length === 0 && (
        <p className="px-3 py-4 text-xs text-slate-500">No modules match "{navFilter}".</p>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 lg:flex">
      {/* Desktop Left Sidebar */}
      <aside
        aria-label="Primary module navigation"
        className="hidden lg:sticky lg:top-0 lg:flex lg:h-screen lg:w-72 lg:shrink-0 lg:flex-col lg:border-r lg:border-slate-200 lg:bg-white"
      >
        <div className="flex h-16 items-center gap-3 border-b border-slate-200 px-5">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-teal-700 text-white">
            <Store className="h-5 w-5" aria-hidden="true" />
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-bold tracking-tight text-slate-900">{storeName}</p>
            <p className="truncate text-xs text-slate-500">Retail Management</p>
          </div>
        </div>

        <div className="border-b border-slate-100 p-3">
          <label htmlFor="desktop-module-search" className="sr-only">
            Filter modules
          </label>
          <div className="relative">
            <Search
              className="pointer-events-none absolute top-1/2 left-3 h-3.5 w-3.5 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              id="desktop-module-search"
              type="search"
              value={navFilter}
              onChange={(e) => setNavFilter(e.target.value)}
              placeholder="Find module..."
              className="w-full rounded-lg border border-slate-200 bg-slate-50 py-1.5 pr-3 pl-8 text-xs text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4">{renderNavGroups()}</nav>

        <div className="border-t border-slate-200 px-4 py-3 text-xs text-slate-500">
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5">
              <ShieldCheck
                className={`h-3.5 w-3.5 ${adminConfigured ? 'text-teal-700' : 'text-amber-600'}`}
                aria-hidden="true"
              />
              <span>{adminConfigured ? 'Admin Lock Active' : 'Admin Password Unset'}</span>
            </span>
            <span className="font-mono text-[11px]">Local DB</span>
          </div>
        </div>
      </aside>

      {/* Main Column */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Top Application Header */}
        <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-xs">
          <div className="flex h-12 items-center justify-between gap-3 px-3 sm:px-6 lg:h-16">
            <div className="flex min-w-0 items-center gap-2 sm:gap-3">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                aria-label="Open all 16 modules menu"
                aria-expanded={mobileMenuOpen}
                className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg text-slate-700 hover:bg-slate-100 lg:hidden"
              >
                <Menu className="h-5 w-5" aria-hidden="true" />
              </button>

              <div className="min-w-0">
                <h1 className="truncate text-[13px] font-bold tracking-tight text-slate-900 sm:text-base">
                  MY STORE – Retail Management System
                </h1>
                <p className="hidden truncate text-xs text-slate-500 lg:block">
                  {activeMeta.label} · Offline-first IndexedDB storage
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <ConnectivityBadge />
              <PWAInstallButton />
            </div>
          </div>
        </header>

        <OfflineBanner />

        {/* Page Content */}
        <main className="flex-1 px-4 py-5 pb-20 sm:px-6 lg:px-8 lg:py-7 lg:pb-10">
          <div className="mx-auto max-w-7xl">{children}</div>
        </main>
      </div>

      {/* Mobile Fixed Bottom Navigation Bar (under 15% sticky height cap) */}
      <nav
        aria-label="Mobile quick navigation"
        className="fixed right-0 bottom-0 left-0 z-30 border-t border-slate-200 bg-white/95 backdrop-blur-md pb-safe lg:hidden"
      >
        <div className="grid h-14 grid-cols-4 items-center">
          {MOBILE_PRIMARY_TABS.map((tabId) => {
            const meta = MODULE_MAP[tabId];
            const isActive = activeModule === tabId;
            return (
              <button
                key={tabId}
                type="button"
                onClick={() => handleSelect(tabId)}
                aria-current={isActive ? 'page' : undefined}
                className={`flex h-full min-h-[44px] flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors ${
                  isActive ? 'text-teal-700 font-semibold' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <ModuleIcon moduleId={tabId} className="h-4 w-4" />
                <span className="truncate">{meta.shortLabel}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Mobile Full 16-Module Slide-Over Drawer */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-50 flex lg:hidden"
          role="dialog"
          aria-modal="true"
          aria-label="All retail modules navigation"
        >
          <div
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative z-10 flex w-80 max-w-[85vw] flex-col bg-white shadow-2xl">
            <div className="flex h-14 items-center justify-between border-b border-slate-200 px-4">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-teal-700 text-white">
                  <Store className="h-4 w-4" aria-hidden="true" />
                </div>
                <span className="text-sm font-bold text-slate-900">{storeName}</span>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close modules menu"
                className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>

            <div className="border-b border-slate-100 p-3">
              <label htmlFor="mobile-module-search" className="sr-only">
                Filter modules
              </label>
              <div className="relative">
                <Search
                  className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400"
                  aria-hidden="true"
                />
                <input
                  id="mobile-module-search"
                  type="search"
                  value={navFilter}
                  onChange={(e) => setNavFilter(e.target.value)}
                  placeholder="Search 16 modules..."
                  className="w-full min-h-[40px] rounded-lg border border-slate-200 bg-slate-50 py-2 pr-3 pl-9 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:bg-white focus:outline-none"
                />
              </div>
            </div>

            <nav className="flex-1 overflow-y-auto px-3 py-4">{renderNavGroups()}</nav>
          </div>
        </div>
      )}
    </div>
  );
};
