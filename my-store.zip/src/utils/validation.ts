export function isNonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

export function isValidBarcode(barcode: string): boolean {
  const trimmed = barcode.trim();
  return /^[A-Za-z0-9\-_]{3,64}$/.test(trimmed);
}

export function isValidBangladeshMobile(mobile: string): boolean {
  const normalized = mobile.replace(/[\s\-]/g, '');
  return /^(\+?88)?01[3-9]\d{8}$/.test(normalized);
}

export function isNonNegativeInteger(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0;
}

export function validatePasswordStrength(password: string): { valid: boolean; message?: string } {
  if (typeof password !== 'string' || password.length < 6) {
    return {
      valid: false,
      message: 'Admin password must be at least 6 characters long.',
    };
  }
  if (password.length > 128) {
    return {
      valid: false,
      message: 'Admin password cannot exceed 128 characters.',
    };
  }
  return { valid: true };
}

export function assertUniqueValues(values: readonly string[], label: string): void {
  const seen = new Set<string>();
  for (const val of values) {
    const key = val.trim().toLowerCase();
    if (seen.has(key)) {
      throw new Error(`Duplicate ${label} detected: "${val}".`);
    }
    seen.add(key);
  }
}
