export type ErrorCode =
  | 'DATABASE_ERROR'
  | 'CONSTRAINT_ERROR'
  | 'QUOTA_EXCEEDED'
  | 'VALIDATION_ERROR'
  | 'AUTHORIZATION_ERROR'
  | 'BACKUP_ERROR'
  | 'UNKNOWN_ERROR';

export class AppError extends Error {
  public readonly code: ErrorCode;
  public readonly userMessage: string;
  public readonly causeError?: unknown;

  constructor(code: ErrorCode, userMessage: string, technicalMessage?: string, causeError?: unknown) {
    super(technicalMessage ?? userMessage);
    this.name = 'AppError';
    this.code = code;
    this.userMessage = userMessage;
    this.causeError = causeError;
  }
}

export function normalizeError(error: unknown): AppError {
  if (error instanceof AppError) {
    return error;
  }

  if (error && typeof error === 'object') {
    const name = 'name' in error ? String((error as { name: unknown }).name) : '';
    const message = 'message' in error ? String((error as { message: unknown }).message) : '';

    if (name === 'ConstraintError' || message.toLowerCase().includes('uniqueness')) {
      if (message.toLowerCase().includes('barcode')) {
        return new AppError(
          'CONSTRAINT_ERROR',
          'A product with this barcode already exists. Barcodes must be unique.',
          message,
          error
        );
      }
      return new AppError(
        'CONSTRAINT_ERROR',
        'A duplicate record identifier or unique field conflict occurred.',
        message,
        error
      );
    }

    if (name === 'QuotaExceededError') {
      return new AppError(
        'QUOTA_EXCEEDED',
        'Device storage is full. Export a JSON backup and free storage space before continuing.',
        message,
        error
      );
    }

    if (name === 'DatabaseClosedError' || name === 'OpenFailedError') {
      return new AppError(
        'DATABASE_ERROR',
        'Local IndexedDB storage could not be opened. Check browser storage permissions.',
        message,
        error
      );
    }

    if (error instanceof Error) {
      return new AppError('UNKNOWN_ERROR', error.message || 'An unexpected error occurred.', error.message, error);
    }
  }

  return new AppError(
    'UNKNOWN_ERROR',
    'An unexpected error occurred while processing your request.',
    String(error),
    error
  );
}
