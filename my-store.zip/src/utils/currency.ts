/**
 * Integer minor-unit (poisha) currency utilities for BDT (৳).
 * 1 BDT = 100 poisha.
 * Avoids floating-point arithmetic errors for financial totals.
 */

const POISHA_PER_BDT = 100;

export function toPoisha(input: number | string): number {
  if (typeof input === 'number') {
    if (!Number.isFinite(input)) {
      throw new RangeError('Currency amount must be a finite number.');
    }
    return Math.round(input * POISHA_PER_BDT);
  }

  const trimmed = input.trim().replace(/,/g, '');
  if (!/^-?\d+(\.\d+)?$/.test(trimmed)) {
    throw new RangeError(`Invalid currency string: "${input}"`);
  }

  const isNegative = trimmed.startsWith('-');
  const unsigned = isNegative ? trimmed.slice(1) : trimmed;
  const [wholePart, fracPart = ''] = unsigned.split('.');
  const paddedFrac = (fracPart + '00').slice(0, 2);
  const thirdDigit = fracPart.length > 2 ? Number(fracPart[2]) : 0;

  let poisha = Number(wholePart) * POISHA_PER_BDT + Number(paddedFrac);
  if (thirdDigit >= 5) {
    poisha += 1;
  }

  if (!Number.isSafeInteger(poisha)) {
    throw new RangeError('Currency amount exceeds safe integer range.');
  }

  return isNegative ? -poisha : poisha;
}

export function fromPoisha(poisha: number): number {
  if (!Number.isFinite(poisha)) {
    return 0;
  }
  return Math.trunc(poisha) / POISHA_PER_BDT;
}

export function formatBDT(
  poisha: number,
  options: { showDecimals?: boolean; symbol?: string } = {}
): string {
  const { showDecimals = true, symbol = '৳' } = options;
  const safePoisha = Number.isFinite(poisha) ? Math.trunc(poisha) : 0;
  const isNegative = safePoisha < 0;
  const absPoisha = Math.abs(safePoisha);
  const whole = Math.floor(absPoisha / POISHA_PER_BDT);
  const cents = absPoisha % POISHA_PER_BDT;

  const formattedWhole = whole.toLocaleString('en-US');
  const value = showDecimals
    ? `${formattedWhole}.${String(cents).padStart(2, '0')}`
    : formattedWhole;

  return isNegative ? `-${symbol}${value}` : `${symbol}${value}`;
}

export function calculateBasisPointsPoisha(amountPoisha: number, basisPoints: number): number {
  const safeAmount = Math.trunc(amountPoisha);
  const safeBps = Math.trunc(basisPoints);
  return Math.round((safeAmount * safeBps) / 10000);
}

export function sumPoisha(values: readonly number[]): number {
  let total = 0;
  for (const val of values) {
    total += Math.trunc(val);
  }
  return total;
}
