export function generateId(prefix = ''): string {
  let raw: string;
  if (typeof globalThis.crypto !== 'undefined' && typeof globalThis.crypto.randomUUID === 'function') {
    raw = globalThis.crypto.randomUUID();
  } else {
    const timePart = Date.now().toString(36);
    const randPart = Math.random().toString(36).slice(2, 10);
    raw = `${timePart}-${randPart}`;
  }
  return prefix ? `${prefix}_${raw}` : raw;
}

export function getTodayISODate(now: Date = new Date()): string {
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function addDaysISODate(days: number, from: Date = new Date()): string {
  const target = new Date(from.getTime());
  target.setDate(target.getDate() + days);
  return getTodayISODate(target);
}
