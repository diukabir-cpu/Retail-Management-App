import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateBasisPointsPoisha,
  formatBDT,
  fromPoisha,
  sumPoisha,
  toPoisha,
} from './currency';

test('toPoisha converts decimal strings and numbers without floating-point drift', () => {
  assert.equal(toPoisha('19.99'), 1999);
  assert.equal(toPoisha('0.10'), 10);
  assert.equal(toPoisha('1250.50'), 125050);
  assert.equal(toPoisha('-45.25'), -4525);
  assert.equal(toPoisha(0.1 + 0.2), 30);
});

test('fromPoisha and formatBDT render BDT currency cleanly', () => {
  assert.equal(fromPoisha(15050), 150.5);
  assert.equal(formatBDT(0), '৳0.00');
  assert.equal(formatBDT(125050), '৳1,250.50');
  assert.equal(formatBDT(-500), '-৳5.00');
  assert.equal(formatBDT(125000, { showDecimals: false }), '৳1,250');
});

test('calculateBasisPointsPoisha and sumPoisha use integer arithmetic', () => {
  // 5% (500 bps) of ৳1,000.00 (100000 poisha) = 5000 poisha (৳50.00)
  assert.equal(calculateBasisPointsPoisha(100000, 500), 5000);
  assert.equal(sumPoisha([100, 250, 50]), 400);
});
