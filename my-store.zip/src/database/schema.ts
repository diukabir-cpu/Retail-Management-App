import type { AppSettings } from '../types/database';

export const DB_NAME = 'MyStoreRetailDB';
export const CURRENT_SCHEMA_VERSION = 1;
export const BACKUP_FORMAT_VERSION = 1;

export const STORE_NAMES = [
  'products',
  'categories',
  'subcategories',
  'vendors',
  'vendorDocuments',
  'batches',
  'stockLedger',
  'purchases',
  'purchaseItems',
  'sales',
  'saleItems',
  'customers',
  'memberships',
  'returns',
  'returnItems',
  'vendorPayments',
  'cheques',
  'expenses',
  'settings',
  'activityLogs',
] as const;

export type StoreName = (typeof STORE_NAMES)[number];

export const STORE_INDEX_SCHEMA_V1: Record<StoreName, string> = {
  products: 'id, &barcode, &sku, name, categoryId, subcategoryId, isActive',
  categories: 'id, &name, code, isActive',
  subcategories: 'id, categoryId, name, [categoryId+name], isActive',
  vendors: 'id, name, companyName, mobile, isActive',
  vendorDocuments: 'id, vendorId, documentType, uploadedAt',
  batches: 'id, productId, vendorId, purchaseId, batchNumber, expiryDate, [productId+batchNumber], [productId+expiryDate]',
  stockLedger: 'id, productId, batchId, movementType, referenceId, transactionDate, createdAt',
  purchases: 'id, &invoiceId, vendorId, transactionDate, paymentStatus',
  purchaseItems: 'id, purchaseId, productId, batchId',
  sales: 'id, &invoiceId, customerId, transactionDate, paymentStatus, paymentMethod',
  saleItems: 'id, saleId, productId, batchId',
  customers: 'id, &mobile, name, isActive',
  memberships: 'id, &customerId, &cardNumber, tier, isActive',
  returns: 'id, &returnNumber, returnType, referenceInvoiceId, customerId, vendorId, transactionDate',
  returnItems: 'id, returnId, productId, batchId',
  vendorPayments: 'id, vendorId, purchaseId, transactionDate, chequeId',
  cheques: 'id, chequeNumber, vendorId, customerId, maturityDate, status',
  expenses: 'id, category, transactionDate, paymentMethod',
  settings: 'id',
  activityLogs: 'id, action, module, status, createdAt',
};

export function createDefaultSettings(nowISO: string = new Date().toISOString()): AppSettings {
  return {
    id: 'default',
    storeName: 'MY STORE',
    storeSubtitle: 'Retail Management System',
    storePhone: '',
    storeAddress: '',
    currencyCode: 'BDT',
    currencySymbol: '৳',
    defaultVatBasisPoints: 0,
    lowStockDefaultThreshold: 10,
    expiryWarningDays: 30,
    invoicePrefix: 'INV',
    adminCredential: null,
    schemaVersion: CURRENT_SCHEMA_VERSION,
    lastBackupAt: null,
    updatedAt: nowISO,
  };
}
