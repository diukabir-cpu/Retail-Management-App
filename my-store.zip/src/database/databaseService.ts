import type { DashboardSummary, StoreRecordCounts } from '../types/app';
import { addDaysISODate, getTodayISODate } from '../utils/id';
import { normalizeError } from '../utils/errorHandler';
import { sumPoisha } from '../utils/currency';
import { db, initializeDatabase, type MyStoreDatabase } from './db';
import { createDefaultSettings } from './schema';

export async function getStoreRecordCounts(database: MyStoreDatabase = db): Promise<StoreRecordCounts> {
  try {
    await initializeDatabase(database);
    const [
      products,
      categories,
      subcategories,
      vendors,
      vendorDocuments,
      batches,
      stockLedger,
      purchases,
      purchaseItems,
      sales,
      saleItems,
      customers,
      memberships,
      returns,
      returnItems,
      vendorPayments,
      cheques,
      expenses,
      settings,
      activityLogs,
    ] = await Promise.all([
      database.products.count(),
      database.categories.count(),
      database.subcategories.count(),
      database.vendors.count(),
      database.vendorDocuments.count(),
      database.batches.count(),
      database.stockLedger.count(),
      database.purchases.count(),
      database.purchaseItems.count(),
      database.sales.count(),
      database.saleItems.count(),
      database.customers.count(),
      database.memberships.count(),
      database.returns.count(),
      database.returnItems.count(),
      database.vendorPayments.count(),
      database.cheques.count(),
      database.expenses.count(),
      database.settings.count(),
      database.activityLogs.count(),
    ]);

    return {
      products,
      categories,
      subcategories,
      vendors,
      vendorDocuments,
      batches,
      stockLedger,
      purchases,
      purchaseItems,
      sales,
      saleItems,
      customers,
      memberships,
      returns,
      returnItems,
      vendorPayments,
      cheques,
      expenses,
      settings,
      activityLogs,
    };
  } catch (error) {
    throw normalizeError(error);
  }
}

export async function getDashboardSummary(
  database: MyStoreDatabase = db,
  now: Date = new Date()
): Promise<DashboardSummary> {
  try {
    await initializeDatabase(database);

    const today = getTodayISODate(now);
    const settings = (await database.settings.get('default')) ?? createDefaultSettings();
    const expiryCutoff = addDaysISODate(settings.expiryWarningDays, now);

    // Use indexed queries rather than loading the entire database into memory.
    const [totalProducts, totalCustomers, todaySales, activeBatches, activeVendors] = await Promise.all([
      database.products.count(),
      database.customers.count(),
      database.sales.where('transactionDate').equals(today).toArray(),
      database.batches.filter((b) => b.quantityRemaining > 0).toArray(),
      database.vendors.filter((v) => v.outstandingBalancePoisha > 0).toArray(),
    ]);

    const todaySalesPoisha = sumPoisha(todaySales.map((s) => s.totalAmountPoisha));
    const todayDiscountPoisha = sumPoisha(todaySales.map((s) => s.discountPoisha));

    let totalStockUnits = 0;
    const stockByProduct = new Map<string, number>();
    const expiringProductIds = new Set<string>();

    for (const batch of activeBatches) {
      totalStockUnits += batch.quantityRemaining;
      stockByProduct.set(
        batch.productId,
        (stockByProduct.get(batch.productId) ?? 0) + batch.quantityRemaining
      );
      if (batch.expiryDate && batch.expiryDate <= expiryCutoff) {
        expiringProductIds.add(batch.productId);
      }
    }

    let lowStockProducts = 0;
    if (totalProducts > 0) {
      await database.products.each((product) => {
        if (!product.isActive) return;
        const qty = stockByProduct.get(product.id) ?? 0;
        const threshold = product.reorderLevel > 0 ? product.reorderLevel : settings.lowStockDefaultThreshold;
        if (qty <= threshold) {
          lowStockProducts += 1;
        }
      });
    }

    const vendorOutstandingPoisha = sumPoisha(activeVendors.map((v) => v.outstandingBalancePoisha));

    return {
      todaySalesPoisha,
      todayInvoiceCount: todaySales.length,
      todayDiscountPoisha,
      totalProducts,
      totalStockUnits,
      totalCustomers,
      lowStockProducts,
      expiringProducts: expiringProductIds.size,
      vendorOutstandingPoisha,
    };
  } catch (error) {
    throw normalizeError(error);
  }
}
