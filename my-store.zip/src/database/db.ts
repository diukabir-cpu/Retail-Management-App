import Dexie, { type Table, type Transaction } from 'dexie';
import type {
  ActivityLog,
  AppSettings,
  Batch,
  Category,
  Cheque,
  Customer,
  Expense,
  Membership,
  Product,
  Purchase,
  PurchaseItem,
  ReturnItem,
  ReturnRecord,
  Sale,
  SaleItem,
  StockLedgerEntry,
  Subcategory,
  Vendor,
  VendorDocument,
  VendorPayment,
} from '../types/database';
import { generateId } from '../utils/id';
import { normalizeError } from '../utils/errorHandler';
import {
  CURRENT_SCHEMA_VERSION,
  DB_NAME,
  STORE_INDEX_SCHEMA_V1,
  createDefaultSettings,
} from './schema';

export class MyStoreDatabase extends Dexie {
  products!: Table<Product, string>;
  categories!: Table<Category, string>;
  subcategories!: Table<Subcategory, string>;
  vendors!: Table<Vendor, string>;
  vendorDocuments!: Table<VendorDocument, string>;
  batches!: Table<Batch, string>;
  stockLedger!: Table<StockLedgerEntry, string>;
  purchases!: Table<Purchase, string>;
  purchaseItems!: Table<PurchaseItem, string>;
  sales!: Table<Sale, string>;
  saleItems!: Table<SaleItem, string>;
  customers!: Table<Customer, string>;
  memberships!: Table<Membership, string>;
  returns!: Table<ReturnRecord, string>;
  returnItems!: Table<ReturnItem, string>;
  vendorPayments!: Table<VendorPayment, string>;
  cheques!: Table<Cheque, string>;
  expenses!: Table<Expense, string>;
  settings!: Table<AppSettings, string>;
  activityLogs!: Table<ActivityLog, string>;

  constructor(databaseName: string = DB_NAME, options?: { indexedDB?: IDBFactory; IDBKeyRange?: typeof IDBKeyRange }) {
    super(databaseName, options);

    // Version 1: Initial schema for all 20 MY STORE retail entities.
    // Future phases must add version(2), version(3), etc. without modifying v1.
    this.version(CURRENT_SCHEMA_VERSION).stores(STORE_INDEX_SCHEMA_V1);
  }
}

export const db = new MyStoreDatabase();

let initPromise: Promise<void> | null = null;

export async function initializeDatabase(database: MyStoreDatabase = db): Promise<void> {
  if (database === db && initPromise) {
    return initPromise;
  }

  const runInit = async () => {
    try {
      await database.open();
      await database.transaction('rw', database.settings, database.activityLogs, async () => {
        const existing = await database.settings.get('default');
        if (!existing) {
          const nowISO = new Date().toISOString();
          await database.settings.add(createDefaultSettings(nowISO));
          await database.activityLogs.add({
            id: generateId('log'),
            action: 'DATABASE_INITIALIZED',
            module: 'database',
            summary: `IndexedDB schema v${CURRENT_SCHEMA_VERSION} initialized cleanly with 20 stores.`,
            status: 'success',
            metadata: {
              schemaVersion: CURRENT_SCHEMA_VERSION,
            },
            createdAt: nowISO,
          });
        }
      });
    } catch (error) {
      if (database === db) {
        initPromise = null;
      }
      throw normalizeError(error);
    }
  };

  if (database === db) {
    initPromise = runInit();
    return initPromise;
  }
  return runInit();
}

export async function runSafeTransaction<T>(
  mode: 'r' | 'rw',
  tables: Table<unknown, string>[],
  work: (tx: Transaction) => Promise<T>,
  database: MyStoreDatabase = db
): Promise<T> {
  try {
    await initializeDatabase(database);
    return await database.transaction(mode, tables, work);
  } catch (error) {
    throw normalizeError(error);
  }
}
