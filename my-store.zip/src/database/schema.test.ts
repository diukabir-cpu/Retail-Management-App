import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CURRENT_SCHEMA_VERSION,
  STORE_INDEX_SCHEMA_V1,
  STORE_NAMES,
  createDefaultSettings,
} from './schema';

test('schema defines all 20 required IndexedDB stores', () => {
  const expectedStores = [
    'products',
    'categories',
    'subcategories',
    'vendors',
    'vendorDocuments',
    'batches',
    'stockLedger',
    'purchases',
    'purchaseItems',
    'sales',
    'saleItems',
    'customers',
    'memberships',
    'returns',
    'returnItems',
    'vendorPayments',
    'cheques',
    'expenses',
    'settings',
    'activityLogs',
  ];

  assert.equal(STORE_NAMES.length, 20);
  for (const store of expectedStores) {
    assert.ok(STORE_NAMES.includes(store as (typeof STORE_NAMES)[number]), `Missing store: ${store}`);
    assert.ok(STORE_INDEX_SCHEMA_V1[store as (typeof STORE_NAMES)[number]], `Missing index def: ${store}`);
  }
});

test('schema includes required retail indexes', () => {
  assert.ok(STORE_INDEX_SCHEMA_V1.products.includes('&barcode'));
  assert.ok(STORE_INDEX_SCHEMA_V1.products.includes('name'));
  assert.ok(STORE_INDEX_SCHEMA_V1.products.includes('categoryId'));
  assert.ok(STORE_INDEX_SCHEMA_V1.products.includes('subcategoryId'));
  assert.ok(STORE_INDEX_SCHEMA_V1.batches.includes('vendorId'));
  assert.ok(STORE_INDEX_SCHEMA_V1.batches.includes('batchNumber'));
  assert.ok(STORE_INDEX_SCHEMA_V1.batches.includes('expiryDate'));
  assert.ok(STORE_INDEX_SCHEMA_V1.sales.includes('&invoiceId'));
  assert.ok(STORE_INDEX_SCHEMA_V1.sales.includes('transactionDate'));
  assert.ok(STORE_INDEX_SCHEMA_V1.sales.includes('paymentStatus'));
  assert.ok(STORE_INDEX_SCHEMA_V1.customers.includes('&mobile'));
});

test('createDefaultSettings initializes BDT currency and null admin credential', () => {
  const settings = createDefaultSettings('2026-11-18T00:00:00.000Z');
  assert.equal(settings.id, 'default');
  assert.equal(settings.storeName, 'MY STORE');
  assert.equal(settings.currencyCode, 'BDT');
  assert.equal(settings.currencySymbol, '৳');
  assert.equal(settings.adminCredential, null);
  assert.equal(settings.schemaVersion, CURRENT_SCHEMA_VERSION);
});
