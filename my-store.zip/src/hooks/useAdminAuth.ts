import { useCallback, useState } from 'react';
import { isAdminPasswordConfigured } from '../services/settingsService';
import type { ProtectedActionType } from '../types/database';

export interface AuthChallengeRequest {
  action: ProtectedActionType;
  module: string;
  title: string;
  description: string;
  needsInitialSetup: boolean;
  onConfirm: (password: string) => Promise<void>;
}

export function useAdminAuthModal() {
  const [pendingChallenge, setPendingChallenge] = useState<AuthChallengeRequest | null>(null);

  const requestAuthorization = useCallback(
    async (params: Omit<AuthChallengeRequest, 'needsInitialSetup'>) => {
      const configured = await isAdminPasswordConfigured();
      setPendingChallenge({
        ...params,
        needsInitialSetup: !configured,
      });
    },
    []
  );

  const closeChallenge = useCallback(() => {
    setPendingChallenge(null);
  }, []);

  return {
    pendingChallenge,
    requestAuthorization,
    closeChallenge,
  };
}
