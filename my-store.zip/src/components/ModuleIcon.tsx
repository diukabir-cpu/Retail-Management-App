import React from 'react';
import {
  Activity,
  Award,
  BarChart3,
  Building2,
  CalendarClock,
  CreditCard,
  FileSpreadsheet,
  FolderTree,
  Layers,
  LayoutDashboard,
  Package,
  RotateCcw,
  Settings,
  ShoppingCart,
  Truck,
  Users,
} from 'lucide-react';
import type { ModuleId } from '../types/app';

interface ModuleIconProps {
  moduleId: ModuleId;
  className?: string;
}

export const ModuleIcon: React.FC<ModuleIconProps> = ({ moduleId, className = 'h-4 w-4' }) => {
  switch (moduleId) {
    case 'dashboard':
      return <LayoutDashboard className={className} aria-hidden="true" />;
    case 'pos':
      return <ShoppingCart className={className} aria-hidden="true" />;
    case 'products':
      return <Package className={className} aria-hidden="true" />;
    case 'categories':
      return <FolderTree className={className} aria-hidden="true" />;
    case 'subcategories':
      return <Layers className={className} aria-hidden="true" />;
    case 'vendors':
      return <Building2 className={className} aria-hidden="true" />;
    case 'purchases':
      return <Truck className={className} aria-hidden="true" />;
    case 'customers':
      return <Users className={className} aria-hidden="true" />;
    case 'membership':
      return <Award className={className} aria-hidden="true" />;
    case 'returns':
      return <RotateCcw className={className} aria-hidden="true" />;
    case 'payments':
      return <CreditCard className={className} aria-hidden="true" />;
    case 'expiry':
      return <CalendarClock className={className} aria-hidden="true" />;
    case 'reports':
      return <BarChart3 className={className} aria-hidden="true" />;
    case 'master-data':
      return <FileSpreadsheet className={className} aria-hidden="true" />;
    case 'activity-logs':
      return <Activity className={className} aria-hidden="true" />;
    case 'settings':
      return <Settings className={className} aria-hidden="true" />;
  }
};
