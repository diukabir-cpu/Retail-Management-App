import React, { useEffect, useState } from 'react';
import { ArrowLeft, Database, Lock, Settings as SettingsIcon } from 'lucide-react';
import { getStoreRecordCounts } from '../database/databaseService';
import type { ModuleId, ModuleMeta, StoreRecordCounts } from '../types/app';
import { normalizeError } from '../utils/errorHandler';
import { ModuleIcon } from './ModuleIcon';
import { StatusAlert } from './StatusAlert';

interface ModulePlaceholderProps {
  moduleMeta: ModuleMeta;
  onNavigate: (moduleId: ModuleId) => void;
}

export const ModulePlaceholder: React.FC<ModulePlaceholderProps> = ({ moduleMeta, onNavigate }) => {
  const [counts, setCounts] = useState<StoreRecordCounts | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    getStoreRecordCounts()
      .then((res) => {
        if (active) setCounts(res);
      })
      .catch((err) => {
        if (active) setErrorMsg(normalizeError(err).userMessage);
      });
    return () => {
      active = false;
    };
  }, [moduleMeta.id]);

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-teal-50 text-teal-700">
              <ModuleIcon moduleId={moduleMeta.id} className="h-6 w-6" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                <span>Phase 1 Architecture Shell</span>
                <span aria-hidden="true">·</span>
                <span>IndexedDB Schema v1 Ready</span>
              </div>
              <h2 className="mt-1 text-xl font-semibold text-slate-900">{moduleMeta.label}</h2>
              <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-slate-600">
                {moduleMeta.description}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('dashboard')}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              Back to Dashboard
            </button>
            <button
              type="button"
              onClick={() => onNavigate('settings')}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-800"
            >
              <SettingsIcon className="h-4 w-4" aria-hidden="true" />
              Open Settings
            </button>
          </div>
        </div>
      </div>

      {errorMsg && <StatusAlert tone="error" message={errorMsg} />}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <div className="flex items-center gap-2.5">
            <Database className="h-4 w-4 text-teal-700" aria-hidden="true" />
            <h3 className="text-sm font-semibold text-slate-900">
              Connected Local IndexedDB Stores
            </h3>
          </div>
          <p className="mt-1 text-xs text-slate-500">
            Live record counts read directly from Dexie.js stores assigned to this module.
          </p>

          <div className="mt-4 divide-y divide-slate-100 border-t border-slate-100">
            {moduleMeta.stores.map((storeKey) => {
              const count =
                counts && storeKey in counts
                  ? counts[storeKey as keyof StoreRecordCounts]
                  : null;
              return (
                <div key={storeKey} className="flex items-center justify-between py-3 text-sm">
                  <span className="font-mono text-xs text-slate-700">{storeKey}</span>
                  <span className="font-mono text-sm font-semibold tabular-nums text-slate-900">
                    {count === null ? '—' : `${count} records`}
                  </span>
                </div>
              );
            })}
          </div>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <div className="flex items-center gap-2.5">
            <Lock className="h-4 w-4 text-teal-700" aria-hidden="true" />
            <h3 className="text-sm font-semibold text-slate-900">
              Phase 2+ Implementation Guardrails
            </h3>
          </div>
          <ul className="mt-4 space-y-3 text-sm text-slate-600">
            <li className="flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <span>Admin Password Protection</span>
              <span className="font-medium text-slate-900">
                {moduleMeta.requiresAdminForMutations ? 'Required for mutations' : 'Read-only open'}
              </span>
            </li>
            <li className="flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <span>Currency Storage Unit</span>
              <span className="font-mono text-xs font-medium text-slate-900">
                Integer Poisha (৳)
              </span>
            </li>
            <li className="flex items-start justify-between gap-4">
              <span>Transaction Safety</span>
              <span className="font-medium text-slate-900">Atomic Dexie rw transactions</span>
            </li>
          </ul>
        </section>
      </div>
    </div>
  );
};
