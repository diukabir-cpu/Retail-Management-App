import React from 'react';
import { Wifi, WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const ConnectivityBadge: React.FC = () => {
  const isOnline = useOnlineStatus();

  return (
    <div
      role="status"
      aria-live="polite"
      className={`inline-flex items-center gap-1.5 text-xs font-medium whitespace-nowrap shrink-0 ${
        isOnline ? 'text-emerald-700' : 'text-amber-700'
      }`}
    >
      {isOnline ? (
        <>
          <Wifi className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Online</span>
        </>
      ) : (
        <>
          <WifiOff className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Offline Ready</span>
        </>
      )}
    </div>
  );
};

export const OfflineBanner: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) {
    return null;
  }

  return (
    <div
      role="status"
      className="border-b border-amber-200 bg-amber-50 px-4 py-2 text-xs font-medium text-amber-900"
    >
      <div className="mx-auto flex max-w-7xl items-center gap-2">
        <WifiOff className="h-3.5 w-3.5 shrink-0 text-amber-700" aria-hidden="true" />
        <span>
          Offline mode active. All reads and saves are stored directly in local IndexedDB on this device.
        </span>
      </div>
    </div>
  );
};
