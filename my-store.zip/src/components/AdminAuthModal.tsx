import React, { useEffect, useState } from 'react';
import { Lock, ShieldCheck, X } from 'lucide-react';
import type { AuthChallengeRequest } from '../hooks/useAdminAuth';
import { setInitialAdminPassword } from '../services/settingsService';
import { normalizeError } from '../utils/errorHandler';
import { validatePasswordStrength } from '../utils/validation';

interface AdminAuthModalProps {
  challenge: AuthChallengeRequest | null;
  onClose: () => void;
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({ challenge, onClose }) => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setPassword('');
    setConfirmPassword('');
    setErrorMsg(null);
    setSubmitting(false);
  }, [challenge]);

  if (!challenge) {
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (challenge.needsInitialSetup) {
      const check = validatePasswordStrength(password);
      if (!check.valid) {
        setErrorMsg(check.message ?? 'Invalid password.');
        return;
      }
      if (password !== confirmPassword) {
        setErrorMsg('Passwords do not match.');
        return;
      }
    } else if (!password) {
      setErrorMsg('Enter the Admin Password to continue.');
      return;
    }

    setSubmitting(true);
    try {
      if (challenge.needsInitialSetup) {
        await setInitialAdminPassword(password);
      }
      await challenge.onConfirm(password);
      onClose();
    } catch (err) {
      const normalized = normalizeError(err);
      setErrorMsg(normalized.userMessage);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 p-0 backdrop-blur-xs sm:items-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="admin-auth-modal-title"
    >
      <div className="w-full max-w-md rounded-t-3xl border border-slate-200 bg-white p-6 shadow-xl sm:rounded-2xl">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-teal-50 text-teal-700">
              {challenge.needsInitialSetup ? (
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
              ) : (
                <Lock className="h-5 w-5" aria-hidden="true" />
              )}
            </div>
            <div>
              <h2 id="admin-auth-modal-title" className="text-base font-semibold text-slate-900">
                {challenge.needsInitialSetup ? 'Create Admin Password' : challenge.title}
              </h2>
              <p className="text-xs text-slate-500">
                Local authorization · {challenge.action.replace(/_/g, ' ').toLowerCase()}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close authorization dialog"
            className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <p className="mt-3 text-sm leading-relaxed text-slate-600">
          {challenge.needsInitialSetup
            ? 'No Admin Password is set on this device yet. Create a Common Admin Password (hashed locally with PBKDF2-SHA256) to protect sensitive actions and complete this request.'
            : challenge.description}
        </p>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div>
            <label htmlFor="admin-auth-password" className="block text-xs font-medium text-slate-700">
              {challenge.needsInitialSetup ? 'New Admin Password (min 6 characters)' : 'Admin Password'}
            </label>
            <input
              id="admin-auth-password"
              type="password"
              autoFocus
              autoComplete={challenge.needsInitialSetup ? 'new-password' : 'current-password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter admin password"
              className="mt-1.5 block w-full min-h-[44px] rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            />
          </div>

          {challenge.needsInitialSetup && (
            <div>
              <label htmlFor="admin-auth-confirm" className="block text-xs font-medium text-slate-700">
                Confirm Admin Password
              </label>
              <input
                id="admin-auth-confirm"
                type="password"
                autoComplete="new-password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter admin password"
                className="mt-1.5 block w-full min-h-[44px] rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
              />
            </div>
          )}

          {errorMsg && (
            <div
              role="alert"
              className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-700"
            >
              {errorMsg}
            </div>
          )}

          <div className="flex flex-col-reverse gap-2 pt-1 sm:flex-row sm:justify-end">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="min-h-[44px] rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="min-h-[44px] rounded-lg bg-teal-700 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-800 disabled:opacity-50"
            >
              {submitting
                ? 'Verifying...'
                : challenge.needsInitialSetup
                  ? 'Set Password & Continue'
                  : 'Authorize Action'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
