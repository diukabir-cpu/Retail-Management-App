import { useCallback, useEffect, useState } from 'react';
import { AppRouter } from './app/AppRouter';
import { AdminAuthModal } from './components/AdminAuthModal';
import { ErrorBoundary } from './components/ErrorBoundary';
import { StatusAlert } from './components/StatusAlert';
import { initializeDatabase } from './database/db';
import { useAdminAuthModal } from './hooks/useAdminAuth';
import { AppShell } from './layouts/AppShell';
import { getAppSettings } from './services/settingsService';
import type { ModuleId } from './types/app';
import { normalizeError } from './utils/errorHandler';

export default function App() {
  const [activeModule, setActiveModule] = useState<ModuleId>('dashboard');
  const [dbReady, setDbReady] = useState(false);
  const [dbError, setDbError] = useState<string | null>(null);
  const [storeName, setStoreName] = useState('MY STORE');
  const [adminConfigured, setAdminConfigured] = useState(false);

  const { pendingChallenge, requestAuthorization, closeChallenge } = useAdminAuthModal();

  const syncHeaderSettings = useCallback(async () => {
    try {
      const settings = await getAppSettings();
      setStoreName(settings.storeName);
      setAdminConfigured(settings.adminCredential !== null);
    } catch (err) {
      setDbError(normalizeError(err).userMessage);
    }
  }, []);

  useEffect(() => {
    let active = true;
    initializeDatabase()
      .then(() => getAppSettings())
      .then((settings) => {
        if (!active) return;
        setStoreName(settings.storeName);
        setAdminConfigured(settings.adminCredential !== null);
        setDbReady(true);
      })
      .catch((err) => {
        if (!active) return;
        setDbError(normalizeError(err).userMessage);
        setDbReady(true);
      });

    return () => {
      active = false;
    };
  }, []);

  return (
    <ErrorBoundary>
      <AppShell
        activeModule={activeModule}
        storeName={storeName}
        adminConfigured={adminConfigured}
        onSelectModule={setActiveModule}
      >
        {dbError && (
          <div className="mb-6">
            <StatusAlert tone="error" message={dbError} />
          </div>
        )}

        {!dbReady ? (
          <div className="space-y-4" aria-busy="true" aria-label="Initializing local database">
            <div className="h-24 animate-pulse rounded-2xl border border-slate-200 bg-white" />
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <div className="h-32 animate-pulse rounded-2xl border border-slate-200 bg-white" />
              <div className="h-32 animate-pulse rounded-2xl border border-slate-200 bg-white" />
              <div className="h-32 animate-pulse rounded-2xl border border-slate-200 bg-white" />
              <div className="h-32 animate-pulse rounded-2xl border border-slate-200 bg-white" />
            </div>
          </div>
        ) : (
          <AppRouter
            activeModule={activeModule}
            onNavigate={setActiveModule}
            requestAuthorization={requestAuthorization}
            onSettingsUpdated={() => {
              void syncHeaderSettings();
            }}
          />
        )}
      </AppShell>

      <AdminAuthModal challenge={pendingChallenge} onClose={closeChallenge} />
    </ErrorBoundary>
  );
}
