export type ModuleId =
  | 'dashboard'
  | 'pos'
  | 'products'
  | 'categories'
  | 'subcategories'
  | 'vendors'
  | 'purchases'
  | 'customers'
  | 'membership'
  | 'returns'
  | 'payments'
  | 'expiry'
  | 'reports'
  | 'master-data'
  | 'activity-logs'
  | 'settings';

export type NavGroup = 'operations' | 'inventory' | 'people' | 'system';

export interface ModuleMeta {
  id: ModuleId;
  label: string;
  shortLabel: string;
  group: NavGroup;
  description: string;
  phaseStatus: 'active' | 'foundation';
  stores: string[];
  requiresAdminForMutations: boolean;
}

export interface DashboardSummary {
  todaySalesPoisha: number;
  todayInvoiceCount: number;
  todayDiscountPoisha: number;
  totalProducts: number;
  totalStockUnits: number;
  totalCustomers: number;
  lowStockProducts: number;
  expiringProducts: number;
  vendorOutstandingPoisha: number;
}

export interface StoreRecordCounts {
  products: number;
  categories: number;
  subcategories: number;
  vendors: number;
  vendorDocuments: number;
  batches: number;
  stockLedger: number;
  purchases: number;
  purchaseItems: number;
  sales: number;
  saleItems: number;
  customers: number;
  memberships: number;
  returns: number;
  returnItems: number;
  vendorPayments: number;
  cheques: number;
  expenses: number;
  settings: number;
  activityLogs: number;
}

export interface BackupTableData {
  products: unknown[];
  categories: unknown[];
  subcategories: unknown[];
  vendors: unknown[];
  vendorDocuments: unknown[];
  batches: unknown[];
  stockLedger: unknown[];
  purchases: unknown[];
  purchaseItems: unknown[];
  sales: unknown[];
  saleItems: unknown[];
  customers: unknown[];
  memberships: unknown[];
  returns: unknown[];
  returnItems: unknown[];
  vendorPayments: unknown[];
  cheques: unknown[];
  expenses: unknown[];
  settings: unknown[];
  activityLogs: unknown[];
}

export interface BackupPayload {
  appName: 'MY STORE';
  backupFormatVersion: number;
  schemaVersion: number;
  exportedAt: string;
  recordCount: number;
  tables: BackupTableData;
}

export interface BackupValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  summary?: {
    schemaVersion: number;
    exportedAt: string;
    totalRecords: number;
    tableCounts: Record<string, number>;
  };
}
