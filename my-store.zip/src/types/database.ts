export type PaymentStatus = 'paid' | 'partial' | 'unpaid' | 'cancelled';
export type PaymentMethod = 'cash' | 'bkash' | 'nagad' | 'card' | 'bank_transfer' | 'cheque';
export type StockMovementType =
  | 'opening'
  | 'purchase'
  | 'sale'
  | 'return_in'
  | 'return_out'
  | 'adjustment_in'
  | 'adjustment_out'
  | 'expired_writeoff';
export type ChequeStatus = 'pending' | 'cleared' | 'bounced' | 'cancelled';
export type MembershipTier = 'regular' | 'silver' | 'gold' | 'platinum';

export type ProtectedActionType =
  | 'PRODUCT_CREATE'
  | 'PRODUCT_UPDATE'
  | 'PRODUCT_DELETE'
  | 'CATEGORY_CREATE'
  | 'CATEGORY_UPDATE'
  | 'CATEGORY_DELETE'
  | 'SUBCATEGORY_CREATE'
  | 'SUBCATEGORY_UPDATE'
  | 'SUBCATEGORY_DELETE'
  | 'VENDOR_MANAGE'
  | 'CUSTOMER_MANAGE'
  | 'STOCK_ADJUST'
  | 'RETURN_SUBMIT'
  | 'POS_REMOVE_ITEM'
  | 'POS_DISCOUNT_APPLY'
  | 'SETTINGS_UPDATE'
  | 'ADMIN_PASSWORD_SET'
  | 'ADMIN_PASSWORD_CHANGE'
  | 'BACKUP_EXPORT'
  | 'BACKUP_RESTORE';

export interface BaseEntity {
  id: string;
  createdAt: string;
  updatedAt: string;
}

export interface Product extends BaseEntity {
  sku: string;
  barcode: string;
  name: string;
  categoryId: string;
  subcategoryId: string;
  unit: string;
  costPricePoisha: number;
  sellingPricePoisha: number;
  mrpPoisha: number;
  vatBasisPoints: number;
  reorderLevel: number;
  trackExpiry: boolean;
  isActive: boolean;
  notes?: string;
}

export interface Category extends BaseEntity {
  name: string;
  code: string;
  description?: string;
  isActive: boolean;
}

export interface Subcategory extends BaseEntity {
  categoryId: string;
  name: string;
  code: string;
  description?: string;
  isActive: boolean;
}

export interface Vendor extends BaseEntity {
  name: string;
  companyName: string;
  mobile: string;
  email?: string;
  address?: string;
  openingBalancePoisha: number;
  outstandingBalancePoisha: number;
  isActive: boolean;
}

export interface VendorDocument extends BaseEntity {
  vendorId: string;
  title: string;
  documentType: 'trade_license' | 'tin' | 'agreement' | 'invoice_scan' | 'other';
  mimeType: string;
  sizeBytes: number;
  dataUrlOrBase64: string;
  uploadedAt: string;
}

export interface Batch extends BaseEntity {
  productId: string;
  vendorId?: string;
  purchaseId?: string;
  batchNumber: string;
  expiryDate?: string; // ISO YYYY-MM-DD
  costPricePoisha: number;
  sellingPricePoisha: number;
  quantityInitial: number;
  quantityRemaining: number;
}

export interface StockLedgerEntry {
  id: string;
  productId: string;
  batchId?: string;
  movementType: StockMovementType;
  quantityDelta: number;
  balanceAfter: number;
  referenceType: 'purchase' | 'sale' | 'return' | 'adjustment' | 'expiry';
  referenceId: string;
  reason?: string;
  transactionDate: string;
  createdAt: string;
}

export interface Purchase extends BaseEntity {
  invoiceId: string;
  vendorId: string;
  transactionDate: string;
  subtotalPoisha: number;
  discountPoisha: number;
  taxPoisha: number;
  totalAmountPoisha: number;
  paidAmountPoisha: number;
  dueAmountPoisha: number;
  paymentStatus: PaymentStatus;
  notes?: string;
}

export interface PurchaseItem {
  id: string;
  purchaseId: string;
  productId: string;
  batchId: string;
  batchNumber: string;
  expiryDate?: string;
  quantity: number;
  unitCostPoisha: number;
  lineTotalPoisha: number;
}

export interface Sale extends BaseEntity {
  invoiceId: string;
  customerId?: string;
  transactionDate: string;
  subtotalPoisha: number;
  discountPoisha: number;
  taxPoisha: number;
  totalAmountPoisha: number;
  paidAmountPoisha: number;
  changeAmountPoisha: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  notes?: string;
}

export interface SaleItem {
  id: string;
  saleId: string;
  productId: string;
  batchId?: string;
  productName: string;
  barcode: string;
  quantity: number;
  unitPricePoisha: number;
  discountPoisha: number;
  lineTotalPoisha: number;
}

export interface Customer extends BaseEntity {
  name: string;
  mobile: string;
  email?: string;
  address?: string;
  totalSpentPoisha: number;
  loyaltyPoints: number;
  dueBalancePoisha: number;
  isActive: boolean;
}

export interface Membership extends BaseEntity {
  customerId: string;
  cardNumber: string;
  tier: MembershipTier;
  discountBasisPoints: number;
  pointsBalance: number;
  enrolledAt: string;
  expiresAt?: string;
  isActive: boolean;
}

export interface ReturnRecord extends BaseEntity {
  returnNumber: string;
  returnType: 'customer_return' | 'vendor_return';
  referenceInvoiceId: string;
  customerId?: string;
  vendorId?: string;
  transactionDate: string;
  totalRefundPoisha: number;
  reason: string;
  authorizedByActionId?: string;
}

export interface ReturnItem {
  id: string;
  returnId: string;
  productId: string;
  batchId?: string;
  quantity: number;
  unitAmountPoisha: number;
  lineTotalPoisha: number;
  restockable: boolean;
}

export interface VendorPayment extends BaseEntity {
  vendorId: string;
  purchaseId?: string;
  transactionDate: string;
  amountPoisha: number;
  paymentMethod: PaymentMethod;
  chequeId?: string;
  referenceNumber?: string;
  notes?: string;
}

export interface Cheque extends BaseEntity {
  chequeNumber: string;
  vendorId?: string;
  customerId?: string;
  bankName: string;
  issueDate: string;
  maturityDate: string;
  amountPoisha: number;
  status: ChequeStatus;
  notes?: string;
}

export interface Expense extends BaseEntity {
  title: string;
  category: string;
  transactionDate: string;
  amountPoisha: number;
  paymentMethod: PaymentMethod;
  notes?: string;
}

export interface AdminCredentialHash {
  algorithm: 'PBKDF2-SHA256';
  iterations: number;
  saltHex: string;
  hashHex: string;
  updatedAt: string;
}

export interface AppSettings {
  id: 'default';
  storeName: string;
  storeSubtitle: string;
  storePhone: string;
  storeAddress: string;
  currencyCode: 'BDT';
  currencySymbol: '৳';
  defaultVatBasisPoints: number;
  lowStockDefaultThreshold: number;
  expiryWarningDays: number;
  invoicePrefix: string;
  adminCredential: AdminCredentialHash | null;
  schemaVersion: number;
  lastBackupAt: string | null;
  updatedAt: string;
}

export interface ActivityLog {
  id: string;
  action: ProtectedActionType | 'DATABASE_INITIALIZED' | 'AUTH_SUCCESS' | 'AUTH_FAILED';
  module: string;
  summary: string;
  entityId?: string;
  status: 'success' | 'denied' | 'error';
  metadata?: Record<string, string | number | boolean>;
  createdAt: string;
}
